/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
CREATED JD 12.6.19 for Stata Working Group
PURPOSE: To illustrate how to work with macro/loop combos and then give students 
			space to practice it on their own.
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/

//Some good things to have at the top of every program
clear all
set more off

set seed 591113																	//Good habit if you're generating random #s so you get the same answer

//****Generating some data for us to work with****/
	set obs 1000
	gen id=_n
	//Here comes our first forloop!
	forval i=1/25 {																//do the following cmds where i=1,2,3,...25
		gen x`i'=runiform()*10													//create a uniform random variable that ranges 0-10
	}
	
/****SKILL THE FOURTH: LOOPING THROUGH LISTS****
	Let's say the x variables are irregularly spaced repeated measures across 
	5 waves of data of the same 5 variables that we would like to give common 
	names and then reshape.
	
	Sound unlikely? Clearly you haven't worked with the PSID.
	
	Let's give it a try.
*/
	//Here's our list of variables:
	//measured in:	w1  w2  w3  w4  w5
	local agevars	"x1 x6  x12 x21 x25"
	local educvars	"x2 x10 x11 x20 x23"
	local incvars	"x3 x9  x13 x19 x21"
	local marrvars	"x4 x8  x14 x18 x22"
	local chdvars 	"x5 x7  x15 x17 x24"
	
	//This time we'll rename them all and reshape them.
	
	local w=1																	//Just for wave-labeling purposes
	foreach a of local agevars {
		gen agew`w'=`a' 														//Renames the 1st agevar agew1, the 2nd agew2,...
		local ++w																//Increments `ct' by 1
	}
	
/*YOU TRY! Do that for the rest of thev variable lists above*/
	
	//Your code here
	
	//After you've done that, we should be able to reshape the data long
	
	preserve																	//saves the data as-is
		drop x*
		reshape long age@ educ@ inc@ marr@ chd@ , i(id) j(wave) string
		su
		ta wave
	restore																		//restores the data as-was

	drop agew* educw* incw* marrw* chdw*
	
/****SKILL THE FIFTH: PARALLEL LOOPS****
		Here we're going to do the same thing as with the 4th skill, except we'll 
		do it all in one loop.
*/
	
/*YOU TRY! Look back to the animal noise example from the ppt for inspiration.
		I'll just get you started
		(The completed code starts on line 150)*/
		
	local waves=wordcount("`chdvars'")
	forval w=1/`waves' {
		local a=word("`agevars'",`w')
		//fill in the other variables here
		
		gen agew`w'=`a'
	}
	
	//After you've done that, we should be able to reshape the data long
	
	preserve																	//saves the data as-is
		drop x*
		reshape long age@ educ@ inc@ marr@ chd@ , i(id) j(wave) string
		su
		ta wave
	restore	

	//(Completed parallel loop code below:)
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//Completed parallel loop code
	local agevars	"x1 x6  x12 x21 x25"										//These are the same strings of varnames as above, reproduced here for convenience
	local educvars	"x2 x10 x11 x20 x23"
	local incvars	"x3 x9  x13 x19 x21"
	local marrvars	"x4 x8  x14 x18 x22"
	local chdvars 	"x5 x7  x15 x17 x24"
	
	local waves=wordcount("`chdvars'")											//This is handy in case you work with the same code and add more waves later
	forval w=1/`waves' {
		local a=word("`agevars'" ,`w')											//Grabs the wth word from the agevars local
		gen agew`w'=`a'															//New age variable with sensible name
		local e=word("`educvars'",`w')											//Grabs the wth word from the educvars local
		gen educw`w'=`e'														//New education variable with sensible name
		local i=word("`incvars'" ,`w')											//Grabs the wth word from the incvars local
		gen incw`w'=`i'															//New income variable with sensible name
		local m=word("`marrvars'",`w')											//Grabs the wth word from the marrvars local
		gen marrw`w'=`m'														//New marital status variable with sensible name
		local c=word("`chdvars'" ,`w')											//Grabs the wth word from the chdvars local
		gen chdw`w'=`c'															//New child status variable with sensible name
	}
