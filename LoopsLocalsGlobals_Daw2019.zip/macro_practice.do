/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
CREATED JD 12.6.19 for Stata Working Group
PURPOSE: To illustrate how to work with macros and then give students space to 
			practice it on their own.
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/

//Some good things to have at the top of every program
clear all
set more off

set seed 591113																	//Good habit if you're generating random #s so you get the same answer

/****SKILL THE FIRST: REPEATEDLY REFERENCED TEXT****/

	//Fill in this macro with the directory where you would like to save output
	global root "C:\Users\jud36.PSU\Dropbox\0PSU Matters\Service\Stata WG 191206"	//Fill this in with the directory you would like to work out of instead.

	//Then create these directories in that location:
	global data "${root}/Data"
	global logs "${root}/Logs"
	//You could put other programs here, a spot for graphs, tables, whatever.
	
	local date "191206"															//I like to do this as a form of version control for data/output

//****Generating some data for us to work with****/
	set obs 1000
	gen id=_n
	//Here comes our first forloop!
	forval i=1/25 {																//do the following cmds where i=1,2,3,...25
		gen x`i'=runiform()*10													//create a uniform random variable that ranges 0-10
	}
	save "${data}/wgdata_`date'" , replace
	
/****SKILL THE SECOND: LISTS OF VARIABLES/NUMBERS****
	Let's say the x variables are irregularly spaced repeated measures across 
	5 waves of data of the same 5 variables that we would like to give common 
	names and then reshape.
	
	Sound unlikely? Clearly you haven't worked with the PSID.
	
	Let's give it a try.
*/
	//Here's our list of variables:
	//measured in:	w1  w2  w3  w4  w5
	local agevars	"x1 x6  x12 x21 x25"
	local educvars	"x2 x10 x11 x20 x23"
	local incvars	"x3 x9  x13 x19 x21"
	local marrvars	"x4 x8  x14 x18 x22"
	local chdvars 	"x5 x7  x15 x17 x24"
	
	//Here we're going to reference different items in these lists using the word() function:
	
	local agew3=word("`agevars'",3)												//Wave 3 age measure
	di "The wave 3 age measure is `agew3'"
	global incw5=word("`incvars'",5)											//Wave 5 income measure
	di "The wave 5 income measure is ${incw5}"
	
	//Hmmmmm, how many waves are there?
	local wavect=wordcount("`agevars'")
	di "`wavect'"
	
	/*YOU TRY! Grab the wave 2 marriage measure, the wave 1 child measure, and 
	the wave 4 education measure, and then display a statement saying what they 
	are. Try them using both locals and globals.*/
	
	//Your code goes here
	
	/*YOU TRY! for good measure, try counting how many different chd vars there 
	are here:*/
	
	//Your code goes here

