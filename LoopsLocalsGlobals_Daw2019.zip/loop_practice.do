/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
CREATED JD 12.6.19 for Stata Working Group
PURPOSE: To illustrate how to work with loops and then give students space to 
			practice it on their own.
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/

//Some good things to have at the top of every program
clear all
set more off
set seed 591113																	//Good habit if you're generating random #s so you get the same answer

//****Generating some data for us to work with****/
	set obs 1000
	gen id=_n
	//Here comes our first forloop!
	forval i=1/25 {																//do the following cmds where i=1,2,3,...25
		gen x`i'=runiform()*10													//create a uniform random variable that ranges 0-10
		replace x`i'=ceil(x`i')													//rounds to the next integer up
	}
	
/****SKILL THE THIRD: LOOPING THROUGH VARIABLES****
	Let's say the x variables are need to be generated into a new variable that
	needs recoding and then checking against the original. That'd be a pain!
	
	Let's practice using foreach and forval instead.
*/
	forval i=1/25 {																//substitutes the #s 1-25 for `i'
		gen newx`i'=x`i'														//eg, gen newx1=x1
		recode newx`i' (1/5=0) (6/10=1)											//recode to dichotomous form
		ta x`i' newx`i'															//checks the original against the recode - always a good habit!
	}
	
	su																			//let's see what things look like now
	drop newx*
	
/*YOU TRY! Practice using the n1(n2)n3 format of forval here. Let's say you need 
			to recode the odd x's in the way we did above but leave the even x's 
			as-is. How would you do that?*/
	
	//Your code goes here
	
	su
	drop newx*
	
//Now let's try doing the same as the above using foreach.
	
	foreach a of varlist x* {													//This works if there are no other vars besides x1-x25 that start with x
		gen new`a'=`a'															//eg, gen newx1=x1
		recode new`a' (1/5=0) (6/10=1)											//recode to dichotomous form
		ta `a' new`a'															//checks the original against the recode - always a good habit!
	}
	
	su
	drop newx*
	
/*YOU TRY! What if we only need to recode x4, x10, x19, and x22?*/
	
	//Your code goes here


