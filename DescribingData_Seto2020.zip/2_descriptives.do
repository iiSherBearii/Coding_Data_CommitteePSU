********************************************************************************
** Title: DESCRIBING YOUR DATA
* Purpose: To introduce the new cohort to Stata commands for describing variables

* Creation Date: 	11.01.20
* Last Edited:   	11.02.20
* Created by:	 	Chris Seto
* Last Edited by:	Chris Seto
********************************************************************************

/* COMMANDS LEARNED IN THIS DO FILE:

lookfor						// searches variable names and labels for keywords
describe   					// gives general information about variable type, display format, and label
summarize 					// The useful one. gives descriptive stats about variable distribution (N, mean, SD, min, max. More info with detail option)
tabulate 					// gives (1 or 2) variable probability distributions. Extremely useful. Note missing, column, and row options.
codebook 					// gives information on type, label, range, missing values, examples, unique values. 
list 						// lists actual values for a variable. 
sort 						// sorts observations (rows) in ascending order
order 						// moves the position of a variable (column) in your dataset
*/

********************************************************************************
** STARTING YOUR DO FILE
********************************************************************************
clear // clears any open datasets
clear matrix
clear mata //these are good habits too
set more off, permanent

* Tell STATA where on your computer to find your data using the "cd" command
cd "FILE PATH"  

* OPEN THE STATA DATA SET
use CSAF_2018.dta, clear
numlabel, ad

*LOOKFOR COMMAND
lookfor ghosts 

* DESCRIBE COMMAND
describe qn20k

* SUMMARIZE COMMAND
summarize qn20k

summarize qn20k, detail

*TABULATE COMMAND
tabulate qn20k //one variable gives univariate distribution

tabulate qn20k, missing //note that the variable is presently coded with no missing (blank values are -1)

tabulate qn20k SEX //two variables gives joint distribution. just cell counts if no option specified.

tabulate qn20k SEX, row //cell counts and percentages that sum to 100 across the rows

tabulate qn20k SEX, column //cell counts and percentages that sum to 100 down the columns

*CODEBOOK COMMAND
codebook qn20k

*LIST COMMAND
list qn20k

list qn20k in 1/5 //lists only the first 5 values

list qn20k SEX in 1/5 //lists 2 vars together

list qn20k in 1/5 if SEX == 1 //lists values conditionally

*SORT COMMAND
sort AGE // sorts observations (rows) by age in ascending order

*ORDER COMMAND
order AGE, last //moves the variable (column) of age to the end of the dataset


