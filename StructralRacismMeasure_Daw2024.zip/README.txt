*******************************************
# Construction Measures of Structural Racism
# For Data & Coding Workshop 
# JD Daw
# 5.14.24
*******************************************

## Data source is IPUMS CDOH: https://cdoh.ipums.org/download

## Identifiers:
- year
- statefips
- countyfips

## 5 Measures of SR:
1. **Educational inequity** in racism-county-educational-inequity folder. Key vars:
 a. edu_ratio_wanh_ba: 	Educational inequity between White alone, Not Hispanic or Latino, and Black alone
 b. edu_ratio_wanh_h:	Educational inequity between White alone, Not Hispanic or Latino, and Hispanic or Latino
 c. edu_ratio_wanh_aa: 	Educational inequity between White alone, Not Hispanic or Latino, and Asian alone
2. **Employment inequity** in racism-county-employment-inequity folder. Key vars:
 a. emp_wanh_ba Employment inequity between White alone, Not Hispanic or Latino, and Black alone
 b. emp_wanh_h Employment inequity between White alone, Not Hispanic or Latino, and Hispanic or Latino
 c. emp_wanh_aa Employment inequity between White alone, Not Hispanic or Latino, and Asian alone
3. **Homeownership** in racism-county-homeownership-inequity folder. Key vars:
 a. ho_wanh_ba Homeownership inequity between White alone, Not Hispanic or Latino-headed households, and Black alone-headed households
 b. ho_wanh_h Homeownership inequity between White alone, Not Hispanic or Latino-headed households, and Hispanic or Latino-headed households
 c. ho_wanh_aa Homeownership inequity between White alone, Not Hispanic or Latino-headed households, and Asian alone-headed households
4. **Income inequity** in racism-county-income-inequity folder. Key vars: 
 a. ice_wanh_ba Income inequity between White alone, Not Hispanic or Latino-headed households, and Black alone-headed households
 b. ice_wanh_h Income inequity between White alone, Not Hispanic or Latino-headed households, and Hispanic or Latino-headed households
 c. ice_wanh_aa Income inequity between White alone, Not Hispanic or Latino-headed households, and Asian alone-headed households
5. **Residential segregation** in racism-county-residential-segregation folder. Key vars:
 a. d_wa_ba Index of dissimilarity between White alone and Black alone 
 b. d_wanh_h Index of dissimilarity between White alone, Not Hispanic or Latino, and Hispanic or Latino
 c. d_wa_aa Index of dissimilarity between White alone and Asian alone 

## County race/ethnicity-specific life expectancy, 2015-19. 
- Peer reviewed paper: https://doi.org/10.1016/S0140-6736(22)00876-5
- Download site: https://ghdx.healthdata.org/record/ihme-data/united-states-life-expectancy-by-county-race-ethnicity-2000-2019 
- For interactive data visualizatioj: https://vizhub.healthdata.org/subnational/usa. 
- For code used in the analysis: https://github.com/ihmeuw/USHD.
