/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
CREATED JD 5.14.24

PURPOSE 
1. To construct structural racism measures using average, summative, and CFA approaches.
2. To test association of each SR measure version with race-specific life expectancy.

NOTE: This version of the .do file leaves you things to fill in in each section. It won't work until you do! Marked by !!!!
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/

clear all
set more off
version 17.0																											//Set whatever version you're working with
capture log close
set tracedepth 1

cd "/Users/elenapojman/Library/CloudStorage/OneDrive-ThePennsylvaniaStateUniversity/Coding & Data Committee/Open Access Documents/2024 Workshops/Session 3 - measuring race + racism/SR_Coding" //Fill with root directory where you're working from

log using "./Output/sr_le_practice.log" , text replace

//Toggles
global recode_sr	= 1																									//Merges raw SR & recodes SR measures
global recode_le	= 1
global merge_sr_le	= 1
global sr_test		= 1

// Merging SR indicators together and recoding
if (${recode_sr}==1) {
	//Read in each file, keep needed vars and obs, save in tempfile for subsequent merging
		local c=1
		foreach x in racism-county-educational-inequity racism-county-employment-inequity racism-county-homeownership-inequity racism-county-income-inequity racism-county-residential-segregation {
		import delimited using "./IPUMS_CDOH/`x'/`x'.csv" , delimiters(",") clear								//If your Stata copy is super old, use -insheet- instead
			de 
			keep if year=="2015-2019"			//Will predict race/eth specific LE0 in 2019
			drop state county
			di "File is `x', c is `c'..."
			tempfile d`c'
			save `d`c''
			local ++c
		}
	
	//Load first file then merge the other four
		use `d1' , clear
		forval c=2/5 {
			merge 1:1 statefips countyfips using `d`c''
			drop _merge
		}
		de
	
	//Combine statefips and countyfips into one fips code mergeable with LE file
		//LE fips does not have leading 0s, but does have filler 0s. Eg statefips=1 & countyfips=1 -> fips=1001.
		gen 	fips = .
		replace fips = (statefips * 1000) + countyfips 
		preserve
			gen u = runiform()
			sort u 
			li statefips countyfips fips in 1/100 //Checking correct on random subset of counties
		restore 
	
	//Standardize in three ways: Cumulative distribution scaled 0-100, z-score, and dummy variable with 75th perc cutoff
		foreach x of varlist edu* emp* ho* ice* d_* {
			//Cumulative distribution
				cumul `x' , gen(c_`x')
				replace c_`x' = round(c_`x'*100,.01)
				su 		`x' c_`x'
				corr 	`x' c_`x'
			
			//Z-score
				qui su `x' , detail
				local mn=r(mean)
				local sd=r(sd)
				gen z_`x' = (`x' - `mn') / `sd'
				su 		`x' z_`x'
				corr 	`x' z_`x'
			
			//Dummy variable with 75th perc cutoff 
				qui su `x' , detail
				local p75 = r(p75)
				gen 	dv_`x' = (`x' >= `p75')
				replace dv_`x' = . if mi(`x')
				su 		`x' dv_`x'
				ta 	dv_`x' , su(`x')		
		}
		
	//Construct sr indices
		local wabb_h 	"wanh_h"																						//WANH only comparison for H, not for BA or AA for dissimilarity
		local wabb_ba	"wa_ba"
		local wabb_aa 	"wa_aa"
		foreach s in c z dv {
			foreach r in ba h aa {
				
				egen sr_avg_`s'_`r' 	= rowmean(`s'_edu_ratio_wanh_`r' `s'_emp_ratio_wanh_`r' `s'_ho_ratio_wanh_`r' /// //Average 
											`s'_ice_wanh_`r' `s'_d_`wabb_`r'')
				
				egen sr_sum_`s'_`r' 	= rowtotal(`s'_edu_ratio_wanh_`r' `s'_emp_ratio_wanh_`r' `s'_ho_ratio_wanh_`r' /// //Average 
											`s'_ice_wanh_`r' `s'_d_`wabb_`r'')							
				
			}							
		}
			
	//Keep needed variables and save file to merge with LE data
		keep statefip countyfip fips sr_*
		save "./Output/sr.dta" , replace
}

if (${recode_le}==1) {
	//Load life expectancy file for 2019, both sexes
		import delimited using "./LE_Race_County/IHME_USA_LE_COUNTY_RACE_ETHN_2000_2019_LT_2019_BOTH_Y2022M06D16.csv" , delimiters(",") clear
		
	//Drop ages other than <1 year
		keep if age_name=="<1 year"
		
	//Drop USA-wide and state-wide estimates
		drop if location_name=="United States of America" | fips < 1000													//State FIPS are 1-56, lowest county FIPS is 1001
		
	//Drop all-race/ethnicity calculations
		drop if race_name=="Total"
		
	//Drop unneeded variables 
		drop measure_id measure_name location_id race_id sex_id sex_name age_group_id age_name year metric_id metric_name 
		
	//Reshape the data wide (so each county is one row with LE_White, LE_Black, etc)
		rename val 		LE_ 
		rename upper	LE_UL_
		rename lower 	LE_LL_
		reshape wide LE_@ LE_UL_@ LE_LL_@ , i(fips) j(race_name) string 
		
	//Save file to merge with SR data
		save "./Output/le.dta" , replace
}

if (${merge_sr_le}==1) {
	//Load sr file
		use "./Output/sr.dta" , clear
		merge 1:1 fips using "./Output/le.dta"
		li fips sr* LE_Black LE_White _merge if _merge != 3																//94 mismatched counties, all missing data on one side or the other, as expected
		drop if _merge!=3
		drop _merge 
		save "./Output/sr_le_comb.dta" , replace 
}

if (${sr_test}==1) {
	//Go nuts! See what you find.
	// explore relationship at county level the LE and structural racism indices
}


log close
