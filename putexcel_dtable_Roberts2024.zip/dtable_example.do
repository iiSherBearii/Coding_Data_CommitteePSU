/*==============================================================================
DTABLE TUTORIAL: 
Created by Mary Roberts (mkr5635@psu.edu)
Created 02.24.20

Purpose: to teach dtable for the PSU coding and data committee 

OUTLINE OF THIS FILE: 
1) Basic example using dtable to create a table 1 (descriptive table) 
2) Example with grouping variable
	2A) Statistics
	2B) Tests
3) Formatting 

BASICS OF DTABLE SYNTAX:
	dtable [varlist] [if] [in] [weight] , [options]
	
	- Default statistics for 
		> continous variables = mean (semean)
		> factor = frequency (%)
	- Default tests for 
		> Continuous variables = regress
		> Factor = pearson's chi-squared test
		
===============================================================================*/
cd "C:\Users\mlrob\OneDrive - The Pennsylvania State University\Coding and Data\Putexcel and Dtabel"		// set your working directory

log using "dtable_example.txt", replace		// open your log file 
webuse "nlsw88.dta", clear			//load the National Longitudinal Surveys - Women's Sample
describe		// Decribe the variables in your dataset
	/* Returns Variable Name, Storage Type, Display Format, Value Label, Variable Label 
	
 Observations:         2,246                  NLSW, 1988 extract
    Variables:            17                  1 May 2220 22:52 
                                              (_dta has notes)
---------------------------------------------------------------------------------------
Variable      Storage   Display    Value
    name         type    format    label      Variable label
---------------------------------------------------------------------------------------
idcode          int     %8.0g                 NLS ID
age             byte    %8.0g                 Age in current year
race            byte    %8.0g      racelbl    Race
married         byte    %8.0g      marlbl     Married
never_married   byte    %16.0g     nev_mar    Never married
grade           byte    %8.0g                 Current grade completed
collgrad        byte    %16.0g     gradlbl    College graduate
south           byte    %9.0g      southlbl   Lives in the south
smsa            byte    %9.0g      smsalbl    Lives in SMSA
c_city          byte    %16.0g     ccitylbl   Lives in a central city
industry        byte    %23.0g     indlbl     Industry
occupation      byte    %22.0g     occlbl     Occupation
union           byte    %8.0g      unionlbl   Union worker
wage            float   %9.0g                 Hourly wage
hours           byte    %8.0g                 Usual hours worked
ttl_exp         float   %9.0g                 Total work experience (years)
tenure          float   %9.0g                 Job tenure (years)
---------------------------------------------------------------------------------------
*/

*******************************************************************************
* 1) Basic example using dtable
*******************************************************************************

	/*For this example we will produce a table with descriptive for:
		// Continuous variables: age, grade, wage, hours, ttl_exp, and tenure
		// Factor variables (i.[var]): race, married, collgrad, and south 
	//Export options
			Suffix		File format		Output format
			docx		as(docx)		Microsoft Word
			html		as(html)		HTML 5 with CSS
			pdf			as(pdf)			PDF
			xlsx		as(xlsx)		Microsoft Excel 2007/2010 or newer
			xls			as(xls)			Microsoft Excel 1997/2003
			tex			as(latex)		LaTeX
			smcl		as(smcl)		SMCL
			txt			as(txt)			Plain text
			markdown	as(markdown)	Markdown
			md			as(markdown)	Markdown
	*/
	
		dtable age grade wage hours ttl_exp tenure i.race i.married i.collgrad i.south,  export("dtable_example.xlsx", replace sheet("example1", replace))	// telling dtable we want the summary statistics for these variables, and we are going to export the results to the excel file and sheet that we labeled


*******************************************************************************
* 2) Example with grouping variable 
*******************************************************************************

	/*What if we want to sort out data by race?
		- by options 
			[no]tests                                show or suppress tests across groups
			[no]testnotes                            show or suppress notes about tests across groups
			[no]totals                               show or suppress statistics for the total sample
			[no]missing                              show or suppress numeric missing values in varname
			
	*/
	
	dtable age grade wage hours ttl_exp tenure i.married i.collgrad i.south, by(race)	// same as above, but now we are going to break our sample into sub-samples by race
	
	/* What is you want more than the default statistics?
		- cstats (continuous variables)         
										Definition
                     ---------------------------------------------------
                     mean           mean
                     semean         standard error of the mean
                     sebinomial     standard error of the mean, binomial
                     sepoisson      standard error of the mean, Poisson

                     variance       variance
                     sd             standard deviation
                     skewness       skewness
                     kurtosis       kurtosis
                     cv             coefficient of variation
                     svycv          coefficient of variation (svy)

                     geomean        geometric mean
                     geosd          geometric standard deviation

                     count          number of nonmissing values

                     median         median
                     p#             #th percentile
                     q1             first quartile
                     q2             second quartile
                     q3             third quartile
                     iqr            interquartile range

                     min            minimum value
                     max            maximum value
                     range          range

                     first          first value
                     last           last value
                     firstnm        first nonmissing value
                     lastnm         last nonmissing value

                     total          total
                     rawtotal       unweighted total
                     ---------------------------------------------------


		- fstats (factor variables)
											Definition
                   ------------------------------------------------------------
                   fvfrequency      frequency of each factor-variable level
                   fvpercent        percentage within each factor-variable
                                      level
                   fvproportion     proportion within each factor-variable
                                      level

                   fvrawfrequency   unweighted frequency of each
                                      factor-variable
                                      level
                   fvrawpercent     unweighted percentage within each
                                      factor-variable level
                   fvrawproportion  unweighted proportion within each
                                      factor-variable level
                   ------------------------------------------------------------
	*/

	
	dtable, by(race, nototals tests)																///  telling dtable to sort the results by race (White/Black/Other)
		sample(, statistic(frequency) place(seplabels))												///  telling dtable that under the subgroup titles, we want the frequency of each sub group and that the freqquencies should be stacked under the labels
		continuous(age grade, statistics(mean min max))												///  we want these continuous statistics first (age and grade), and we want mean min and max statistics 
		factor(married collgrad south, statistics(fvfrequency fvproportion))						///  telling dtable that we want these factor variables next, and we want the frequency and the proportion
		continuous(wage hours ttl_exp tenure, statistics(mean min max))								///  these continuous variables are next, same statistics as before
		export("dtable_example.xlsx",modify  sheet("example2", replace))							// export the results to the same excel file, but a new sheet
	

	
*******************************************************************************
* 3) Formatting- Let's make the table pretty!
*******************************************************************************

	dtable, by(race, nototals tests testnotes)														/// telling dtable to sort the results by race (White/Black/Other)  
		sample(, statistic(frequency) place(seplabels))												/// telling dtable that under the subgroup titles, we want the frequency of each sub group and that the freqquencies should be stacked under the labels
		continuous(age grade, statistics(mean minmax))												/// we want these continuous statistics first (age and grade), and we want mean min and max statistics 
		factor(married collgrad south, statistics(fvfrequency fvproportion))						/// telling dtable that we want these factor variables next, and we want the frequency and the proportion
		continuous(wage hours ttl_exp tenure, statistics(mean minmax))								/// these continuous variables are next, same statistics as before
		define(minmax = min max,  delimiter(-)) nformat(%6.2f  mean minmax fvproportion) 			///	So, according to the table above of cstats, "minmax" is not an option. So this line tell stata that we want to define "minmax" to be equal to the variables min value and max value. the "delimiter(-)" option tells it that we want the two values to be separated by a "-". nformat is the option for formatting numerical values in stata. "%9.2f" is telling stata that we want the following statistics to be right-aligned and have a fixed 2 decimal places (this will keep 0's)
		sformat("(%s)" minmax fvproportion)															///	
		title("Table 1: Descriptive Statistics")												    ///
		notes("Please enjoy making tables!")														///
		export("dtable_example.xlsx",modify  sheet("example3", replace))
	
	
	
		dtable, by(race, nototals tests testnotes)														/// telling dtable to sort the results by race (White/Black/Other)  
		sample(, statistic(frequency) place(seplabels))												/// telling dtable that under the subgroup titles, we want the frequency of each sub group and that the freqquencies should be stacked under the labels
		continuous(age grade, statistics(meansd))												/// we want these continuous statistics first (age and grade), and we want mean min and max statistics 
		factor(married collgrad south, statistics(fvfrequency fvproportion))						/// telling dtable that we want these factor variables next, and we want the frequency and the proportion
		continuous(wage hours ttl_exp tenure, statistics(meansd))								/// these continuous variables are next, same statistics as before
		define(meansd = mean sd,  delimiter(±)) nformat(%6.2f  meansd fvproportion) 			///	So, according to the table above of cstats, "minmax" is not an option. So this line tell stata that we want to define "minmax" to be equal to the variables min value and max value. the "delimiter(-)" option tells it that we want the two values to be separated by a "-". nformat is the option for formatting numerical values in stata. "%9.2f" is telling stata that we want the following statistics to be right-aligned and have a fixed 2 decimal places (this will keep 0's)
		sformat("(%s)" fvproportion)															///	
		title("Table 1: Descriptive Statistics")												    ///
		notes("Please enjoy making tables!")														///
		export("dtable_example.xlsx",modify  sheet("example4", replace))
	
	log close