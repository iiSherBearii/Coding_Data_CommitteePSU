cd "/Users/dmr45/Library/CloudStorage/OneDrive-ThePennsylvaniaStateUniversity/Spring 2026/Coding Committee/Data and Do-Files/"

capture log close

log using "Stata HLM Workshop.log", replace	
use "Dave NNCS Data - 4-14-2026.dta", clear


 
/****************
Describe data & summary statistics
****************/

tab cit_name

d t_vl4r2 t_vl4c2 t_dsdh2 c_dsdh2 t_frbr2  t_rsi22 t_pmin2 t_lnpo2 c_lnpo2 c_pmin2 c_forbr2 c_south2 c_west2 

sum t_vl4r2 t_vl4c2 t_dsdh2 c_dsdh2 t_frbr2  t_rsi22 t_pmin2 t_lnpo2 c_lnpo2 c_pmin2 c_forbr2 c_south2 c_west2 


xtset city_id tract2

xtsum t_vl4r2 t_vl4c2 t_dsdh2 c_dsdh2 t_frbr2  t_rsi22 t_pmin2 t_lnpo2 c_lnpo2 c_pmin2 c_forbr2 c_south2 c_west2 




/*****************************************************************************************************************************************************
Building Multilevel Model
*****************************************************************************************************************************************************/

/*********
Null Model & Calculate ICC
*********/

mixed t_vl4r2 ||city_id:

estat icc	


/*********
Adding Level-1 Variables
*********/

mixed t_vl4r2 t_dsdh2 ||city_id:

*calculating the Proportional Reduction in Variance (PRV)
display "Level-1 R-Squared: " (60.8581 - 43.41976) / 60.8581

*calculating the Proportional Reduction in Variance (PRV)
display "Level-2 R-Squared: " (21.60868 - 13.44303) / 21.60868

/*********
Adding Level-2 Variables
*********/	

mixed t_vl4r2 t_dsdh2 c_dsdh2 ||city_id:

*calculating the Proportional Reduction in Variance (PRV)
display "Level-1 R-Squared: " (60.8581 - 43.41985) / 60.8581

*calculating the Proportional Reduction in Variance (PRV)
display "Level-2 R-Squared: " (21.60868 - 13.16546) / 21.60868

/*********
Centering
*********/

*calculating group and grand means for Level-1 variables
foreach var of varlist t_frbr2 t_dsdh2 t_rsi22 t_pmin2 t_lnpo2 {
egen mean_`var' = mean(`var'), by(city_id)
sum `var', meanonly
gen grand_`var' = `var' - r(mean)	
gen group_`var'= `var' - mean_`var' 
	
}

*calculating grand means for Level-2 variables
foreach var of varlist c_dsdh2 c_lnpo2 c_pmin2 c_forbr2 c_south2 c_west2  {
egen mean_`var' = mean(`var'), by(city_id)
sum `var', meanonly
gen grand_`var' = `var' - r(mean)	
	
}
	

sum t_dsdh2 c_dsdh2 mean_t_dsdh2 grand_t_dsdh2  group_t_dsdh2



corr t_dsdh2 c_dsdh2 mean_t_dsdh2 grand_t_dsdh2  group_t_dsdh2


mixed t_vl4r2 t_dsdh2 c_dsdh2 ||city_id:
estimates store raw

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2 ||city_id:
estimates store grand

mixed t_vl4r2 group_t_dsdh2 grand_c_dsdh2 ||city_id:
estimates store group

*testing for a contextual "effect"  
test group_t_dsdh2 = grand_c_dsdh2


esttab  raw grand group, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Original Metric" "Grand Mean Centered" "Group Mean Centered")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC"))  
	
	
/*********
Full ML vs. Restricted ML
*********/	

mixed t_vl4r2 t_dsdh2 ||city_id:, mle
estimates store ml

mixed t_vl4r2 t_dsdh2 ||city_id:, reml
estimates store rem

esttab  ml rem, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Full Maximum Likelihood" "Restricted Maximum Likelihood")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC"))  
	

	
/*********
Covariance structure
*********/	

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2 ||city_id:t_dsdh2,cov(unstructured)
estimates store unstructured

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2 ||city_id:t_dsdh2,cov(independent)
estimates store identity

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2 ||city_id:t_dsdh2,cov(identity)
estimates store independent

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2 ||city_id:t_dsdh2,cov(exchangeable)
estimates store exchangeable



esttab unstructured identity independent exchangeable, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Cov(Identity)" "Cov(Unstructured)")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC")) 

		
	
/*********
Random slopes
*********/	

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2  ||city_id:,cov(unstructured)  
estimates store not

mixed t_vl4r2 grand_t_dsdh2 grand_c_dsdh2  ||city_id:t_frbr2,cov(unstructured) 
estimates store random



esttab  not random, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Random Intercepts" "Random Slopes")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC")) 

lrtest  not random 


	
/*********
Non-linearity
*********/	

menbreg t_vl4c2  grand_t_dsdh2 grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2 grand_c_dsdh2 grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un) 
estimates store not

menbreg t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un)  irr
estimates store random 



esttab  not random, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Random Intercepts" "Random Slopes")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC")) 
	
/*********
Cross-level interactions
*********/	


menbreg t_vl4c2  grand_t_dsdh2 grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2 grand_c_dsdh2 grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un) 
estimates store not

menbreg t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un)  irr
estimates store random 



esttab  not random, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Random Intercepts" "Random Slopes")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC")) 
	
	
	
/*********
Model Fit
*********/		
	
*Run the Reduced Model (No interaction)
menbreg t_vl4c2  grand_t_dsdh2 grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2 grand_c_dsdh2 grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un) 
estimates store reduced

*Run the Full Model (With interaction)
menbreg t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un)  
estimates store full

*Compare the fit
estimates stats reduced full


*Predict BOTH random effects (Intercept and Slope)
predict u0_diag u1_diag, reffects

*Now run the Q-Q plot on the city-level intercept residuals
qnorm u0_diag, title("Normality of City-Level Intercepts")

*(Optional) Run it on the random slopes to see if 'neighborhood sensitivity' is normal
qnorm u1_diag, title("Normality of Neighborhood Effect Variation")

* Predict the fixed-portion values
predict yhat_fixed, xb

* Scatter residuals against predictions
scatter u0_diag yhat_fixed, yline(0) ///
    title("City Residuals vs. Fitted Values") ///
    xtitle("Predicted Log-Crime") ytitle("City-Level Residual")
	
*Standardize the random intercept and random slope
egen u0_std = std(u0_diag)
egen u1_std = std(u1_diag)

*List the cities that are "extreme" outliers (more than 3 SDs away)
list city_id u0_std u1_std if abs(u0_std) > 3 | abs(u1_std) > 3	

* Create a measure of combined 'extreme-ness'
gen influence_proxy = abs(u0_std) + abs(u1_std)

* Scatter plot with bubbles sized by influence
twoway (scatter u1_diag u0_diag [weight=influence_proxy], mlabel(city_id) msize(vsmall) msymbol(circle_hollow)), ///
    title("City-Level Influence Diagnostic") ///
    xtitle("Random Intercept (Baseline Crime)") ///
    ytitle("Random Slope (Neighborhood Sensitivity)") ///
    yline(0) xline(0)
	
 
	
/*********
Post-Estimation
*********/	


menbreg t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un)  irr

*Calculate the 'Simple Slopes' at specific levels of city disadvantage
margins, dydx(grand_t_dsdh2) at(grand_c_dsdh2=(-1(.5)1)) 

*Plot those slopes to show the moderation effect
marginsplot, yline(0) recast(line) recastci(rarea) ///
    title("The Moderating Effect of City Context") ///
    xtitle("City Disadvantage (Standardized)") ///
    ytitle("Marginal Effect of Tract Disadvantage")
	
	

*Predict the random Intercept (u0), the random Slope (u1), 
* and their Standard Errors (se0, se1)
predict u0 u1, reffects reses(se0 se1)

*Create a rank variable based on the random slope (u1)
egen rank_slope = rank(u1)

*Generate the Caterpillar Plot
* scale(1.96) creates the 95% Confidence Interval
serrbar u1 se1 rank_slope, yline(0) scale(1.96) ///
    title("Caterpillar Plot: Variation in Neighborhood Effect") ///
    xtitle("Ranked Cities (Low to High Sensitivity)") ///
    ytitle("Deviation from Average Tract Effect") ///
    msize(tiny)
	
	
gen low = u1 - 1.96*se1
gen high = u1 + 1.96*se1

twoway (rcap low high rank_slope, lcolor(gs12)) ///
       (scatter u1 rank_slope, msize(tiny) mcolor(black)), ///
    yline(0) legend(off) title("Cleaned Caterpillar Plot")
	
	*Calculate Expected Counts (n) using the manual exponentiation expression

	
*Store the margins result in Stata's memory
margins, at(grand_t_dsdh2=(-2(1)2) grand_c_dsdh2=(-1 0 1)) expression(exp(predict(xb))) post

*Export the stored result to a .tex file
esttab using "InteractionTable.tex", ///
    cells("b(fmt(3)) p(fmt(3))") ///
    label title(Marginal Effects of Neighborhood Disadvantage) ///
    nonumbers replace booktabs fragment ///
    star(* 0.05 ** 0.01 *** 0.001)

*Plot the relationship
marginsplot,   ///
    title("Hypothetical Relationship: Neighborhood Effect by City Type") ///
    xtitle("Neighborhood Disadvantage") ///
    ytitle("Expected Number of Crimes") ///
    legend(label(1 "Low Disadvantage City") label(2 "Average City") label(3 "High Disadvantage City")) 
	
graph export "InteractionPlot.png", as(png) replace width(2000)

menbreg t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) ||city_id:t_dsdh2,cov(un)  irr
estimates store mixed 


meglm t_vl4c2  c.grand_t_dsdh2##(c.grand_c_dsdh2) grand_t_rsi22 grand_t_pmin2 grand_t_frbr2 grand_t_lnpo2  grand_c_lnpo2 grand_c_pmin2 grand_c_forbr2 c_south2 c_west2,exp(t_pop082) || city_id: grand_t_dsdh2, family(nbinomial) link(log) covariance(unstructured)
estimates store meglm 


esttab  mixed meglm, ///
    b(3) se(3) ///                      
    star(* 0.05 ** 0.01 *** 0.001)  ///
    label ///                           
    mtitle("Random Intercepts" "Random Slopes")  ///
    stats(N ll aic bic, labels("N" "LogLik" "AIC" "BIC")) 
	
	


/*****************************************************************************************************************************************************
Building a model w/ Panel Data
*****************************************************************************************************************************************************/
use "NLSY-CYA Stata Data.dta", replace


reshape long agech recogz bpintz bpextz,i(cpubid) j(year)


drop if agech <6

foreach var of varlist agech recogz bpintz bpextz {
drop if `var' ==.

	
}

xtset cpubid agech


/*********
Centering 
*********/


*Time (age and date) depends on how we are using these variables in our model
sum  agech recogz bpintz bpextz

replace agech = agech - 6

sum  agech recogz bpintz bpextz

xtsum  agech recogz bpintz bpextz

foreach var of varlist agech recogz bpintz {
egen mean_`var' = mean(`var'), by(cpubid)
sum `var', meanonly
gen grand_`var' = `var' - r(mean)	
gen group_`var'= `var' - mean_`var' 
	
}



/*********
Null Model & Calculate ICC
*********/

mixed bpextz ||cpubid:

estat icc	

/*********
Growth Curve Models 
*********/


*Age
mixed bpextz  agech i.year ||cpubid: agech
*Age-squared
mixed bpextz  c.agech##c.agech i.year ||cpubid: 
*Age-squared (kids within moms)
mixed bpextz  c.agech##c.agech i.year ||mpubid:  ||cpubid:

 
mixed bpextz recogz c.agech##c.agech i.year ||mpubid:  ||cpubid:


mixed bpextz recogz c_brst_fed c.agech##c.agech i.year ||mpubid:  ||cpubid:


/*********
xtreg - Fixed vs. Random Effects vs. Population Average Models
*********/


*Run Fixed Effects (Level-2)
xtreg bpextz recogz c_brst_fed c.agech##c.agech i.year , fe 
estimates store fixed1

*Run Random Effects (Level-2)
xtreg bpextz recogz c_brst_fed c.agech##c.agech i.year , re 
estimates store random

*The Hausman Test
hausman fixed1 random


*Run Fixed Effects (Level-2)
xtreg bpextz group_recogz c_brst_fed c.group_agech##c.group_agech i.year , fe 
estimates store fixed1

*Run Random Effects (Level-2)
xtreg bpextz group_recogz c_brst_fed c.group_agech##c.group_agech i.year , re 
estimates store random

*The Hausman Test
hausman fixed1 random

*Run Population Avg. (Level-2)
xtreg bpextz group_recogz c_brst_fed c.group_agech##c.group_agech i.year , pa 
estimates store random

*Run Two-Way Fixed Effects (Level-2)
xtreg bpextz recogz c_brst_fed i.agech i.year , fe 
estimates store twoway


/*********
Post-estimation - growth curves
*********/




*Run Growth Curve Model (Random Slope)
mixed bpextz recogz c_brst_fed c.agech##c.agech i.year ||cpubid:agech, cov(unstructured)

*Get the Fixed Portion (The average line for everyone)
predict base_line, xb

*Get the Random Effects 
* This creates 'u0' for the intercept and 'u1' for the slope
predict u*, reffects

*Hand-calculate the Total Predicted Curve
* Total = (Fixed Intercept + u0) + (Fixed Slope + u1)*Age
gen y_hat_total = (_b[_cons] + u1) + (_b[agech] + u2)*agech

*Create a Spaghetti Plot to visualize growth (Using a subset of sample to avoid overload)
twoway (line bpextz agech if mpubid >= 10000 & mpubid < 10025, connect(ascending) color(red) lw(thin)) ///  // Observed Spaghetti
       (line y_hat_total agech if mpubid >= 10000 & mpubid < 10025, connect(ascending) color(black) lw(thick)) ///        // HLM Fitted Curves
       , legend(order(1 "Observed Data" 2 "HLM Predicted Curves")) ///
       xtitle("Child Age (Centered at 6)") ytitle("Externalizing Score") ///
       title("NLSY79 Longitudinal Growth Spaghetti Plots")


 
*Marginal effects

mixed bpextz recogz c_brst_fed c.agech##c.agech i.year ||cpubid:agech, cov(unstructured)


mixed bpextz recogz c_brst_fed##(c.agech##c.agech) i.year ||cpubid:agech, cov(unstructured)

* Calculate predicted scores at different levels of Mother's Education
margins, at(agech =(0(2)12) c_brst_fed=(0 1))

* Plot the theoretical "Clean" lines
marginsplot, title("Predicted Growth by Breastfed Status") ///
            xtitle("Years since Age 6") ytitle("Predicted Score")


*Initialize output document
putdocx begin

*Create a title
putdocx paragraph, style(Heading1)
putdocx text ("Table 1: Growth Curve Models")

*Run your models and store them
mixed bpextz recogz c_brst_fed c.agech##c.agech i.year ||cpubid:agech, cov(unstructured)
estimates store model1

mixed bpextz recogz c_brst_fed##(c.agech##c.agech) i.year ||cpubid:agech, cov(unstructured)
estimates store model2

*Export the stored results directly to the document
putdocx table results = etable

*Save the file to your Documents folder
putdocx save "NLSY_Results_Table.docx", replace



