install.packages("tidycensus")
library(tidycensus)
library(tidyverse)
library(tigris)
library(sf)
library(ggplot2)
library(viridis)

options(tigris_class = "sf")
options(tigris_use_case = TRUE)

census_api_key("996a52dd57f52f29292620dced4623001992a714", install = TRUE, overwrite = TRUE)

# get variable names from Social Explorer: https://www.socialexplorer.com/data/ACS2019_5yr/metadata/?ds=ACS19_5yr

#########################################

# create new variable that is a string of the variables I want to be using; make sure you get numerator AND denominator
# add "E" to the end of each variable name so you can get the estimate
paper_variables <- c("B03003_003E", "B03003_001E", # here I am getting Hispanic population
                     "B25011_013E", "B25011_037E", "B25011_001E") # female-headed HHs: renter + owner occupied 

# get data for Texas counties in 2019
paper_data <- get_acs(state = 48, 
                      geography = "county",
                      variables = paper_variables,
                      year = 2019,
                      output = "wide",
                      geometry = TRUE)

# get data for all counties in 2019
paper_data2 <- get_acs(geography = "state",
                       variables = paper_variables,
                       year = 2019,
                       output = "wide",
                       geometry = TRUE)

# make variable for % of county that is Hispanic
paper_data$pct_Hisp <- (paper_data$B03003_003E / paper_data$B03003_001E) * 100
paper_data2$pct_Hisp <- (paper_data2$B03003_003E / paper_data2$B03003_001E) * 100

# make variable for % of county that is female-headed household
paper_data$pct_fhh <- ((paper_data$B25011_013E + paper_data$B25011_037E) / paper_data$B25011_001E) * 100
paper_data2$pct_fhh <- ((paper_data2$B25011_013E + paper_data2$B25011_037E) / paper_data2$B25011_001E) * 100

attach(paper_data) # so that the data becomes part of R and we don't have to put it in front of variables each time
attach(paper_data2)

# create categorical bins
paper_data$cat <- ifelse(paper_data$pct_Hisp < 15.01, "< 15%",
                         ifelse(paper_data$pct_Hisp < 20.01, "15-20%",
                                ifelse(paper_data$pct_Hisp < 25.01, "20-25%",
                                       ifelse(paper_data$pct_Hisp < 15.01, "25-30%",
                                              "30%+"))))
paper_data2$cat <- ifelse(paper_data2$pct_Hisp < 15.01, "< 15%",
                         ifelse(paper_data2$pct_Hisp < 20.01, "15-20%",
                                ifelse(paper_data2$pct_Hisp < 25.01, "20-25%",
                                       ifelse(paper_data2$pct_Hisp < 15.01, "25-30%",
                                              "30%+"))))

# plot Hispanics!!
ggplot(
  paper_data2,
       aes(fill = cat)) +
    geom_sf() +
    labs(x = NULL,
         y = NULL,
         title = "% Hispanic",
         subtitle = "ACS, 2015-2019") +
    theme(legend.title = element_blank(),
          legend.position = "bottom",
          plot.title = element_text(size = 16),
          plot.subtitle = element_text(size = 14))

# plot female-headed households!!
ggplot(
  paper_data,
  aes(fill = pct_fhh)) +
  geom_sf() +
  labs(x = NULL,
       y = NULL,
       title = "% female-headed",
       subtitle = "ACS, 2015-2019") +
  theme(legend.title = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(size = 16),
        plot.subtitle = element_text(size = 14))


#########################################


# case study: Internet Access in Puerto Rico

pr_internet <- get_acs(
  state = 72,
  geography = "county",
  variables = c(nointernet = "B28002_013", total = "B28002_001"),
  year = 2020,
  geometry = TRUE,
  output = "wide"
)

pr_internet$pct <- (pr_internet$nointernetE / pr_internet$totalE) * 100
  
# plot % lacking internet!!
ggplot(
  pr_internet,
  aes(fill = pct)) +
  geom_sf() +
  labs(x = NULL,
       y = NULL,
       title = "% lacking internet",
       subtitle = "ACS, 2020") +
  theme(legend.title = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(size = 16),
        plot.subtitle = element_text(size = 14)) +
  scale_fill_continuous(trans = 'reverse') 

# Next steps: read "A Reproducible Framework for Visualizing Demographic Distance Profiles in US Metropolitan Areas" 
  # by Kyle Walker
# https://link.springer.com/article/10.1007/s40980-018-0042-7

