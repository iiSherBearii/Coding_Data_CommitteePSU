// LCA workshop 2025

// pull in Generations data
use "/Users/elenapojman/Downloads/lca_example.dta", clear

ren *, lower

// you'll need to download these commands
*search distinct
*ssc install fre, replace

// check that all ids are distinct 
distinct studyid
assert `r(ndistinct)' == `r(N)'

// explore data
desc

// pick some indicator variables
fre out_*

// let's drop observations that have any missingness in our indicator variables
drop if missing(out_family, out_sfriend, out_coworker, out_healthcare)

misstable sum out_family out_sfriend out_coworker out_healthcare

fre out_family out_sfriend out_coworker out_healthcare

foreach var in out_family out_sfriend out_coworker out_healthcare {
	drop if `var' == 5
}

// recodes
recode orientation_central_identity (1/3 = 0 "disagree") (4/6 = 1 "agree"), gen(centralid)
fre centralid

recode community_linked (1/2 = 1 "agree") (3/4 = 0 "disagree"), gen(linked)
fre linked

recode community_activism (1/2 = 1 "agree") (3/4 = 0 "disagree"), gen(activism)
fre activism

*********** LCA ***********

// (1) compare model fit statistics
mat F = J(10, 3, .)
forval c = 1/10 {
	di ""
	di "`c' class model"

	quietly gsem (centralid linked activism out_family_2 out_sfriend_2 <-, logit) ///
	[pw = w1weight_full], lclass(C `c') ///
	difficult technique(nr 10 bhhh 20) iter(100)
	estimates store mod`c'
	
	// model fit statistics
	estat lcgof
		mat F[`c', 1] = `c'
		mat F[`c', 2] = `r(bic)'
		mat F[`c', 3] = `r(aic)'
	
	continue
}
mat colnames F = num BIC AIC
mat list F

putexcel set "modelfitstats"
putexcel A1 = mat(F)

// compare the models
est stat mod1 mod2 mod3 mod4 mod5 mod6 mod7 mod8 mod9 mod10

// (1.5) go to the "elbow" and look at rhos and gammas
forval c = 2/4 {
	di ""
	di "`c' class model"

	quietly gsem (centralid linked activism out_family_2 out_sfriend_2 <-, logit) ///
	[pw = w1weight_full], lclass(C `c') ///
	difficult technique(nr 10 bhhh 20) iter(100) 
	estimates store mod`c'
	
	// model regression results
	mat b = e(b)'
	mat list b
	
	// latent class prevalences
	estat lcprob
	
	// item-response probabilities
	estat lcmean

}

// (2) assume we pick the 3-class model 
gsem (centralid linked activism out_family_2 out_sfriend_2 <-, logit), lclass(C 3) ///
	difficult technique(nr 10 bhhh 20) iter(100)
	estimates store mod3
	
** assign observations to classes based on modal posterior probability
predict cpost*, classposteriorpr
sum cpost*

egen modal = rowmax(cpost*)
gen class = .
forval c = 1/3 {
	replace class = `c' if cpost`c' == modal
}
tab class

** create weighting variable
gen weight = modal * w1weight_full
sum weight

// (3) prediction fun
** distal outcome
logit out_coworker_2 i.class [pw = weight]
margins class
marginsplot, recast(bar)

** predicting group membership
mlogit class i.out_coworker_2 [pw = weight]
margins out_coworker_2
marginsplot, recast(bar) by(out_coworker_2) xtitle("")
