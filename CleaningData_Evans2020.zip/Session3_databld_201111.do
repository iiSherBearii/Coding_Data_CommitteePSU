/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
CREATED Megan Evans 11.11.20
UPDATED Megan Evans 11.11.20

PURPOSE To demonstrate basic data cleaning commands in Stata

DATA State-Level Homelessness Data for 1933 and 2018

#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/

*Import CSV File

import delimited "C:\Users\mme5163\The Pennsylvania State University\Wirth, Bianca - Coding Committee\2020 - Stata Sessions\Session 3\Data\HTN30_90_.csv", clear


*Rename variables
rename v14 white_pop1930
rename v15 black_pop1930
rename v3  total_pop1930
rename v1b state_abr
rename v41 homeless_pop1930


*Replace Value in Variable
replace state_abr = "DC" if state_abr==""

*Replace Value in Variable 
replace state_number = 51 if state_number==49

*Recode Variable
recode total_pop1930 0/999999=0 1000000/12588066=1, gen(overmil_pop1930)
list total_pop1930 overmil_pop1930 in 1/10

*Clone variables
clonevar statename = v1a
clonevar state_number = v1
	
*Generate new variables
gen perc_white_pop1930	= (white_pop1930/total_pop1930)*100
gen perc_black_pop1930	= (black_pop1930/total_pop1930)*100
gen homelessness_rate1930 = (homeless_pop1930/total_pop1930)*10000

*Create National Summary Measures for Homelessness Data
egen nat_homeless_pop1930 = total(homeless_pop1930)
tab nat_homeless_pop1930

*Drop variables not using
drop v1a v1

*Keep only the relevant variables you need for analysis NOTE: don't forget to keep you ID variable!!
keep statename state_number state_abr white_pop1930 black_pop1930 total_pop1930 homeless_pop1930 overmil_pop1930 perc_white_pop1930 perc_black_pop1930 nat_homeless_pop1930 homelessness_rate1930


*Create quantile variable for homelessness rate
xtile homelessnessR_quant1930 = homelessness_rate1930, n(4)

*Standardize variable 
zscore homelessness_rate1930

*Combine two string variables into one
egen StateInfo = concat(statename state_abr), punct(,)
list StateInfo statename state_abr in 1/5

*Replacing part of string variable with a differnet character
replace StateInfo = subinstr(StateInfo,",","-",.)
list StateInfo in 1/5

*Identifying if a specific character is in your string variable
gen Astate=1 if strpos(StateInfo, "A")

*Assert a logical statement is true in your data
assert Astate==1 if state_abr=="AL"
assert Astate==1 if state_abr=="CO"

*Split one string variable into 2
split StateInfo, parse(-) gen(s_)
list StateInfo s_* in 1/5

help strpos

*String a Variable
tostring state_number, gen(stateN_string) format(%02.0f)

*Destring a Variable
destring stateN_string, gen(stateN_num)


***get Jason's info for groupme

