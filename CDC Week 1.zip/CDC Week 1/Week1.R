#################################################
  
# R Lab 2026
#----> Week 1 R Basics or R is not so Hard (We Promise!)
#----> global, local, use, browse, export, save

################################################

#0. Install and Load Libraries =====
#Today we will only use two libraries,
#However, part of the advantage of R is the myriad of powerful and flexible tools. 

#Install Tidyverse
#Tidyverse is a collection of powerful data management,cleaning, and visualization tools

if (!require("tidyverse")) install.packages("tidyverse")
library(tidyverse) 
?tidyverse

#Install Haven
#Haven allows you to directly import Stata,SPSS, and SAS files into  
if (!require("haven")) install.packages("haven")
library(haven)
?haven

#1.Importing Data =====

#Haven gives us the nice command read_stata to import the classdata 
#We will import the dataset and save it as df for dataframe

df <- read_stata("classdata.dta")


#You should see the imported dataset on the right side of your R Studio under Data 

#2. Getting Familiar with your Data ====	

#	looking at your data
View(df)
	
#this will open a new window called the data viewer. we can see what our data looks like 
	
#We can also select specific variables to view

#This can be done in base R:
View(df[, c("age", "sex", "race")])

#Or using dplyr from the Tidyverse Library we can use Pipes (%>%)
df %>% select(age, sex, race) %>% View()

#We can also quickly inspect the first few rows in our data 

#In base R:
head(df[, c("age", "sex", "race")])

#dyplr
df %>% select(age, sex, race)

#########################################################################################
#practice problems 

#1. Using Base R or Dplyr how would we view the variables marital, vote16, and god?

#2. What if we wanted to quickly inspect partyid, pres12, and health? 

########################################################################################

#3. saving your data ==== 

#Create Directories similiar to your master do

#OUTPUT DIRECTORIES ====
  
dir.create("moddata", showWarnings = FALSE)

# Save as an R data file
saveRDS(df, file.path("moddata", "classdata.rds"))

# Saves as an RDS file (.rds)


# Save as an Excel file
writexl::write_xlsx(df, file.path("moddata", "classdata.xlsx"))

# Saves as an Excel file (.xlsx)





# Save as a CSV/delimited file
write.csv(df, file.path("moddata", "classdata.csv"), row.names = FALSE)

# Saves as a CSV file (.csv)
		
#4. Finishing an R session (unneccessary but here for example)

# Equivalent to	clear all
#rm(list = ls())

#Ending session
#quit()
 

#########################################################################################
  
#  R Lab 2026
#  Week 1 Part 2: Exploring Your Data or your Data and You :)

  
#########################################################################################

#1. More on Exploring our Data

#open the data browser to explore data

view(df)

#opens the browser for all variables. 
#but what if we are only interested in looking at a few variables? 

df %>% select(age, sex, race) %>% View()

# what if want our data sorted by age? 
  
df <- df[order(df$age), ]

View(df[, c("age", "sex", "race", "realrinc")])

# learn more about our variables 
#Describe Equivalent

df %>%
  select(age, race) %>%
  glimpse()

#describes our age and race variable 

#more detailed information about the variable, how it is coded, etc.
#Codebook Equivalent is Structure in R (str)

str(df$race)

#let's look at another variable 

str(df$sex)


	
#2. basic summary statistics and statistical tests ====

summary(df$age) 


#what is the average age in our sample? 


#do all of these summary statistics make sense? 	
summary(df[, c("age", "sex", "race")])

#this is because our sex and race variables are currently numeric 

df$race <- factor(
  df$race,
  levels = c(1, 2, 3),
  labels = c("White", "Black", "Other")
)


#Table is the more appropriate to summarize categorical variables 

table(df$race)

#However if variable is unlabeled, it may not make sense	
table(df$sex) 

#Let's Break it up by sex

summary(df$age[df$sex == 1])
summary(df$age[df$sex == 2])

#let's look at how the average age in our sample differs according to sex
#in the GSS codebook males are coded as "1" and females are coded as "2" 
# we will talk about how to label the variable in W4

t.test(age ~ sex, data = df)

#runs a ttest - 
#testing the equality of means between the two groups to see if 
#there is a statistically significant difference between the average age of men and 
#the average age of women in our sample

############################################################################################

# practice time!! ===== 

###########################################################################################  

#describe realrinc
#code to describe the "realrinc" variable - what is it? 

  
#code to find the average realrinc income for the entire sample 


#code to find the average realrinc income for men and for women 


#code to run a ttest to see if there is a statistically significant difference 
#between respondent income between men and women 

