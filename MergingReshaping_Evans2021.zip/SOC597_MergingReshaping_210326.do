********************************************************************************
********************************************************************************
*Author:			Megan Evans
*Topic:				SOC597 - Merging and Reshaping Data
*Date Created:		03/25/2021

*E-Mail:			mme5163@psu.edu
*Please contact me with questions. I'm happy to hop on a Zoom with you to troubleshoot any merge/reshape problems you might have!
********************************************************************************
********************************************************************************
global data "C:\Users\mme5163\OneDrive - The Pennsylvania State University\Others\Files for Coding Merge\Data"				

set scheme burd

/*
In order to answer any research question, you will need to be aware of what your unit of analysis is. Are you working with inividual people as your unit? with neighborhoods? with households? with time? Is your unit of analysis nested within another unit? Is time nested within people or places or are children nested within schools? Your unit of analysis helps determine the methods available to you, and also the format of your data. 

This is what brings us to merging and reshaping. Often the data you need to answer your research question will be in separate files or from different sources and you will need to merge them into one dataframe. Sometimes you will also need to reshape the data in order put it in a proper format to be analyzed for your research question.
*/


****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************
****************~~~~~~~~~   RESHAPING  ~~~~~~~~~****************
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************


/*
		
Reshape Syntax (from help file)


           long
        +------------+                  wide
        | i  j  stub |                 +----------------+
        |------------|                 | i  stub1 stub2 |
        | 1  1   4.1 |     reshape     |----------------|
        | 1  2   4.5 |   <--------->   | 1    4.1   4.5 |
        | 2  1   3.3 |                 | 2    3.3   3.0 |
        | 2  2   3.0 |                 +----------------+
        +------------+

        To go from long to wide:

                                            j existing variable
                                           /
                reshape wide stub, i(i) j(j)

        To go from wide to long:

                reshape long stub, i(i) j(j)
                                           \
 
                                           j new variable
										   
In the above code:
(i) is your id variable, it is your unique identifier 
(j) is your a variable which denotes your subobservation, it is nested within your id variable, and
stub is the first part of your variable name which you have repeated measures for


Before using reshape, you need to determine whether the data are in long or wide form.  You also must determine the logical observation (i) and the subobservation (j) by which to organize the data. 


*/


****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************
****************~~~~~~~~~ EXAMPLE DATA ~~~~~~~~~****************
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************


/*
Data Files we are working with

1) STI Data from Chicago Data Portal

	Chlamydia.dta

*/

use "${data}/Chlamydia.dta", clear
browse

/*

1. Our data currently is in wide format

2. Our ID variables, our logical observation (i) is:
communityarea communityareaname

3. Our subobservation within our ID variable we want to organize our data by is:
years

Our variable

    long
        +------------+                  wide
        | i  j  stub |                 +----------------+
        |------------|                 | i  stub1 stub2 |
        | 1  1   4.1 |     reshape     |----------------|
        | 1  2   4.5 |   <--------->   | 1    4.1   4.5 |
        | 2  1   3.3 |                 | 2    3.3   3.0 |
        | 2  2   3.0 |                 +----------------+
        +------------+


   wide
		+-----------------------------------------+                 
        | communityarea  chlfem_2000  chlfem_2001 |                
        |-----------------------------------------|
		| 1					4.1			4.5		  |
		| 2					3.3			3.0		  |
	    +-----------------------------------------+
	
				reshape
				  ^
				  |
				  |
				  \/
   
   long
        +------------------------------+                 
        | communityarea  year  chlfem_ |                 
        |------------------------------|                 
        | 1 			 2000   4.1    |    
        | 1  			 2001   4.5    |  
        | 2  			 2000   3.3    |                
        | 2  			 2001   3.0    |                
        +------------------------------+

*/

reshape long chlfem_ chlmal_, i(communityarea) j(year)
browse

/*
Note the following,

1. (j) is a new variable name I am creating

2. You only include the variable stems in your list of variables you want to reshape, I did not include communityareaname because it was not a variable that changed over my subobsveration, in this case, across years.
*/

/*
Now that we are in long format, we can better visualize (and later model) STI trends overtime.
*/

twoway scatter chlfem_ year, jitter(7) || lfit chlfem_ year || scatter chlmal_ year, jitter(7)  || lfit chlmal_ year

/*
If you want your data to be back in wide format, Stata remembers the variables you have already specified the first time.

 To go back to long after using reshape wide:

                reshape long

 To go back to wide after using reshape long:

                reshape wide


*/

reshape wide
browse 

****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************
****************~~~~~~~~~    MERGING   ~~~~~~~~~****************
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************


/*

There are 3 important things you need to know before merging your data.

1. What is your common, unique, identifier(s) in both datasets? 
	
	They have to have the same variable name.
	They have to be in the same format, i.e., string, numeric, etc.
	They have to match exactly.
		Common Issues: leading 0s, lower or upper case letters, etc.

2. What is the structure of your datasets? This determines the type of merge are you conducting.

	Common Issues: the variable you are selecting to merge on is not unique in your master or using data file

3. What variables do are you merging into your data?

*/

/*

Merge Syntax (from help file)

    One-to-one merge on specified key variables

        merge 1:1 varlist using filename [, options]


    Many-to-one merge on specified key variables

        merge m:1 varlist using filename [, options]


    One-to-many merge on specified key variables

        merge 1:m varlist using filename [, options]

*/



****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************
****************~~~~~~~~~ EXAMPLE DATA ~~~~~~~~~****************
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************


/*
Data Files we are working with

1) STI Data from Chicago Data Portal

	Chlamydia.dta

2) US Census Data from Social Explorer

	census2000.dta
	
3) Shapefile for Chicago Community Areas

	CAshapefile.dta
	
4) LODES Commuting Data

	commuting.dta

*/

/*
Let's merge it with our Chlamydia data with Census data.

The steps to consider

1. What is your common, unique, identifier(s) in both datasets?

2. What is the structure of your datasets? This determines the type of merge are you conducting.

3. What variables do are you merging into your data?

We know that in the Chlamydia dataset communityarea is our unique identifier and that it is in wide format, so our unit of observation is the 77 community areas of Chicago.

Let's look at the census datasets

*/

use "${data}\census2000.dta", clear
browse

/*
Note that rather than the variable name communityarea, the census data's unique variable name is geo_id. We need to rename this variable to be the same name for the merge to work. But otherwise, the variable is in the same format and the data is also wide. 
*/

rename geo_id communityarea

merge 1:1 communityarea using "${data}\Chlamydia.dta", gen(cenus_merge)

/*
Now just for a fun visual I will merge in Chicago's Community Area shapefile, which I have already properly formatted and turned into a Stata dataset for a 1:1 merge so we can visualize our data.
*/

merge 1:1 communityarea using "${data}\CAshapefile.dta"

grmap chlfem_2000, name(chlfem_2000, replace) title("Chlamydia Rate for Females in 2000", size(small)) fcolor(Reds) 

grmap disadvantage_2000, name(disadvantage_2000, replace) title("Community Disadvantage in 2000", size(small)) fcolor(Reds) 

graph combine chlfem_2000 disadvantage_2000 , rows(1) ///
		name(com, replace)  imargin(small) 


/*
One-to-one merges tend to be pretty straightforward as long as you have your unique identifiers and datastructure properly formatted.

What is an example of a many-to-one merge or one-to-many merge though?

*/

*First, know your data
use "${data}\commuting.dta", clear
browse

*Second, make sure you have a unique identifier you can merge on
clonevar geo_id = h_commarea

*Third, merge your data
merge m:1 geo_id using "${data}/census2000.dta", gen(censusmerge)
browse 

/*
many-to-one and one-to-many are the same merge,  the order just depends on what dataset you have open, your master data, and what data you are merging into it, your using data.

So, let's do that in the reverse direction.
*/

*First, know your data
use "${data}\census2000.dta", clear
browse

*Second, make sure you have a unique identifier you can merge on
clonevar h_commarea = geo_id

*Third, merge your data
merge 1:m h_commarea using "${data}/commuting.dta", gen(censusmerge)

		
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************
****************~~~~~~~~~Common Issues ~~~~~~~~~****************
****************~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~****************

/*
Issues
1. Identifiers must match
---string or numeric
---leading 0s or not
---same variable name
---must be unique

2. Making sure the variable names you are merging in are all distinct
3. Check for duplicates
4. Variable _merge already defined
*/
	
