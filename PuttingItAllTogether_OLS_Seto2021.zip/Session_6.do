********************************************************************************
** Title: Putting it all together
* Purpose: Integrate commands learned this semester into a set of analyses one might do for a research project. Also OLS regression.

* Creation Date: 	12.10.20
* Last Edited:   	12.10.20
* Created by:	 	Chris Seto
* Last Edited by:	Chris Seto
********************************************************************************
** STARTING YOUR DO FILE
********************************************************************************


clear // clears any open datasets
clear matrix
clear mata //these are good habits too
set more off, permanent

* Tell STATA where on your computer to find your data using the "cd" command
cd "FILE PATH"  

* OPEN THE STATA DATA SET

use CSAF_2015.dta, clear

numlabel, ad

*LOOK FOR RELEVANT VARIABLES
lookfor paranormal ghosts bigfoot aliens psychic

lookfor education job employment income

*LEARN MORE ABOUT THE RELEVANT VARIABLES
//Q31 is the prefix for variables focused on paranormal beliefs
describe Q31_*

summarize Q31_*

tab Q31_1

//SES variables
describe PPEDUCAT PPINCIMP 

summarize PPEDUCAT PPINCIMP 

tab PPEDUCAT PPINCIMP

hist PPINCIMP //income has a lot of categories, so this might be easier to visualize

*VARIABLE CLEANING
//lots of similar ordinal variables are frequently combined into a scale
recode Q31_1 Q31_2 Q31_3 Q31_4 Q31_5 Q31_6 Q31_7 (-1=.) (1=5) (2=4) (3=2) (4=1) (5=3), gen(r_Q31_1 r_Q31_2 r_Q31_3 r_Q31_4 r_Q31_5 r_Q31_6 r_Q31_7)

alpha r_Q31_1 r_Q31_2 r_Q31_3 r_Q31_4 r_Q31_5 r_Q31_6 r_Q31_7, item gen(paranormal) //this creates the scale, called "paranormal". "item" is a helpful option that shows inter-item correlations

//SES vars don't really need cleaning, instead, I just gave them more intuitive names
clonevar educ = PPEDUCAT
clonevar income = PPINCIMP

*VISUALIZE ANY NEW VARIABLES
hist paranormal

*EXAMINE BIVARIATE RELATIONSHIPS

//association between paranomral and educ
cibar paranormal, over1(educ) //mean levels of paranormal belief over education categories
mean paranormal, over(educ) //same thing, but in a table

//association between paranormal and income
lowess paranormal income, jitter(7) scheme(economist) //shows relationship without parametric assumptions
corr paranormal income //gives correlation coefficient


*OLS REGRESSION MODELS
reg paranormal income, beta //predicting paranormal with income; note that beta provides standardized coefficients

reg paranormal income ib1.educ, beta //predicting paranormal with income and education (treated categorically); note that beta provides standardized coefficients

reg paranormal income ib1.educ ib1.ppagecat ib1.PPGENDER ib1.PPETHM, beta //predicting paranormal with income, education, and sociodemographic controls; note that beta provides standardized coefficients


*POSTESTIMATION PREDICTIONS
margins, at(educ = (1 2 3 4)) atmeans // predicts levels of paranormal belief across education values, holding all other predictors constant
marginsplot // graphs the margins

*EXPORTING RESULTS
asdoc reg paranormal income ib1.educ ib1.ppagecat ib1.PPGENDER ib1.PPETHM, save(my_table) //puts the output table into a nicer looking word doc

