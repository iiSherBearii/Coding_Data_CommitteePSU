/*==============================================================================
PUTEXCEL TUTORIAL: 
Created by Anne Morse (axm5832@psu.edu)
Created 10/01/19
Purpose: to teach putexcel for the PSU coding and data management working group

OUTLINE OF THIS FILE: 
1) Crash course on stored results
	(1A) r-class example
	(1B) e-class example
2) Simple putexcel example with correlation
	(2A) Same example done slightly differently
3) Tab example
4) Formatting
5) Looping examples 
	(5A) Looping through rows
	(5B) Looping through columns
6) Regression output


BASICS OF PUTEXCEL SYNTAX:
	(Step 1) Run the estimation and store the output
	(Step 2) Prepare the excel sheet. The code is:
putexcel set workbookname, sheetname modify
	(Step 3) Label your table
putexcel A# = " some text " 
	(Step 4) Put the output into excel. The code is: 
putexcel A# = matrix(name)	
	OR: 
putexcel A# = (r(name))

 * Note, Step 1 can actually be done after step 2 or step 3. 
===============================================================================*/
cd "C:\Users\axm5832\Box Sync\Coding Brown Bag\PutExcel"	// set wd
webuse auto.dta, clear	// bring in data set from the web
*===============================================================================
* (1) CRASH COURSE ON STORED RESULTS:
*===============================================================================
* (1A) r-class example:
*=======================
/*If you run an r-class command and type 'return list', Stata will summarize 
what was stored */

sum price		// sum price, sum is a r-class command
return list		// returns stored r-class results

/* ANNOTATED OUTPUT FROM RETURN LIST	
scalars:										// says the data is a scalar (like a vector)
                  r(N) =  74					// records the # ob observation
              r(sum_w) =  74
               r(mean) =  6165.256756756757		// records the mean
                r(Var) =  8699525.974268788		// records the variance
                 r(sd) =  2949.495884768919		// records the SD 
                r(min) =  3291					// records the min value
                r(max) =  15906					// records the max value
                r(sum) =  456229				
 */
// You can see that these values are stored as r-class items:  
	display r(mean)			// returns the mean
	display r(max)			// returns the maximum observed price
	display sqrt(r(Var))	// displays the square root of our variance: also our SD!
	
// You can save any value as a 1 X 1 matrix: 
	/* The syntax is:
	matrix NAME = r( )' 
	*/
	matrix mean = r(mean)	// stores the value of the mean into a matrix called "mean"
	matrix list mean		// returning this matrix returns the value for the mean 
	
	// You can give it any name:
	matrix Steve = r(max)
 	// View the matrix Steve (our maximum price)
	matrix list Steve	// returns the value for the maximum price as a 1 X 1 matrix
	
*=======================
* (1B) e-class example:
*=======================
/*If you run an e-class command and type 'ereturn list', Stata will summarize 
what was stored */

regress mpg weight		// regression is an e-class comand
ereturn list			// returns e-class results

// Like with an r-class command, it returns scalars; it also returns matrices
matrix list e(b) 		// returns the 1 X 2 matrix of the coefficients

regress mpg weight length
ereturn list
matrix list e(b) 		// returns the 1 x 3 matrix of the coefficients

*===============================================================================
* 2) Simple putexcel example with correlation
*===============================================================================
// (Step 1) Run the correlation and check stored results
	pwcorr foreign price
	return list

// (Step 2)	Prepare new excel sheet
	/*  the code is: 
	putexcel set workbookname, sheetname modify		*/
	putexcel set 				///
		putexcel_example.xlsx, 	///  set name of workbook here
		sheet(correlation)		/// set name of worksheet here
		modify // this lets it write over the old excel each time you run

// (Step 3) Get the table ready: 
	/* the code is:
	Put excel ul_cell  =  "any text that your heart desires" 	*/
	putexcel ///
		A1 = "Table 1: Correlation of foreign and price"
	
// (Step 4) Put the output into the excel:	
	/* the code is:
	Put excel ul_cell  =  (storedresult)	 */
	putexcel A2 = matrix(r(C)), names	// the names option allows us export the row and col names

*=============================================
* (2A) Same example done slightly differently
*=============================================
/* Instead of capturing the entire correlation matrix, we will just capture the 
single rho value: */
// (Step 1) Run the correlation and check stored results
	pwcorr foreign price
	return list

// (Step 2)	Prepare new excel sheet
	// (we will just add onto our existing sheet)

// (Step 3) Get the table ready: 
	putexcel ///
		F1 = "Table 2: Duplicate example of correlation of foreign and price" ///
		F3 = "Foreign"	///	
		F4 = "Price"	///
		G2 = "Foreign"	///
		H2 = "Price"
// (Step 4) Put the output into the excel:	
	putexcel G4 = (r(rho))
	
*===============================================================================
* 3) Tab example
*===============================================================================
/* Tabs and cross tabs in putexcel are slightly different, and I don't know why. 
Don't let this prevent you from doing cross tabs with putexcel! Here, it's not 
too bad: 	*/	

// (Step 1) Run the tabulation and check stored results
	tab rep78 foreign, m
	return list		// it is stored as a scalar
	ereturn list	// this just returns the results from our last regression

	// Don't worry! This is what we do: 
	/* The code is:
	tab [var1] [var2],  matcell(cell) matrow(rows)		
	and this will save the resutls produced into 2 Stata matrices. Check it out: */
	tab rep78 foreign, m 	///
		matcell(cell)	// matcell(name) stores the results of the cells as a matrix

	matrix list cell 	// Great! Now let's put this into excel: 
	
// (Step 2)	Prepare new excel sheet
	putexcel set				///
		putexcel_example.xlsx, 	///  we're going to keep using the existing workbook 
		sheet(tab)				/// but we'll add a sheet
		modify // this lets it write over the old excel each time you run

// (Step 3) Get the table ready: 
	putexcel ///
		A1 = "Table 3: Cross tab results of foreign and repair record"	///
		A3 = "Repair record in 1978"	///
			A4 = "1 repair"			///
			A5 = "2 repairs"		///
			A6 = "3 repairs"		///
			A7 = "4 repairs"		///
			A8 = "5 repairs"		///
			A9 = " . " 				///
		B2 = "Car Type"				///
			B3 = "Domestic"			///
			C3 = "Foreign"
			
// (Step 4) Put the output into the excel:	
	putexcel B4 = matrix(cell)	
	
// Want Percents? No worries! 
	putexcel D4 = matrix(cell/r(N) * 100 ) /// = your count matrix / N 
		D3 = "Domestic %"			/// label it
		E3 = "Foreign %"			//  label it
	
*===============================================================================
* 4) Formatting
*===============================================================================
/* You can format your excel table from Stata with format options: */
	// Let's re-do the previous table, but formatted: 
	putexcel ///
		G1:K1 = "Table 3: Cross tab results of foreign and repair record", ///
		merge font("Times New Roman", 11) border(bottom, thick) 
		
	/* There are A LOT of formatting options, and it can be tedious to type all 
	of them as an option each time. I like to set them in a few globals, like so: */
	global font "font("Times New Roman", 11)"
	global border "border(bottom)"

// Format our text: 	
	putexcel ///
		G3 = "Repair record in 1978"	///
			G4 = "1 repair"		///
			G5 = "2 repairs"	///
			G6 = "3 repairs"	///
			G7 = "4 repairs"	///
			G8 = "5 repairs"	///
			G9 = " . ",			///
			$font left				// set the font and made it left centered

	putexcel	///
		H3 = "Domestic"			///
		I3 = "Foreign"			///
		J3 = "Domestic %"		///  
		K3 = "Foreign %",  		/// 
		$font hcenter 			// set the font and made it horizontally centered
	
	putexcel ///
		H2:I2 = "Car Type, frequency"	///		
		J2:K2 = "Car Type, %", 			///
		$font $border hcenter merge // here we set the font, added a border, made it centered, and merged cells
					
// Format our numbers: 
	putexcel H4 = matrix(cell), ///
	$font hcenter			// set the font and made it centered
	
// Format our %'s and limit the decimal places shown: 
	putexcel J4 = matrix(cell/r(N) * 100 ), ///
	$font hcenter nformat(#.#)
		
// There are A LOT more formatting options. Explore them and use what works for you.

*===============================================================================
* 5) Looping examples 
*===============================================================================	
webuse nlsw88.dta, clear

{
// some variable cleaning:
clonevar wage_cat = wage
replace wage_cat =1 if wage>0   & wage<=3 
replace wage_cat =2 if wage>3	& wage<=4
replace wage_cat =3 if wage>4   & wage<=5
replace wage_cat =4 if wage>5   & wage<=6
replace wage_cat =5 if wage>6   & wage<=9
replace wage_cat =6 if wage>9	& wage<=13
replace wage_cat =7 if wage>13  & wage<17
replace wage_cat = 8 if wage>17

la var wage_cat "categorical wage"
la val wage_cat wage_la
la def wage_la 1 "$0-3" 2 "$3-4" 3 "$4-5" 4 "$5-6" 5 "$6-9" 6 "$9-13" 7 "$13-17" 8 "$17+"
}

*==================================
* (5A) Looping through rows: 
*==================================	
// Let's do some loops!
/* What if I wanted to put the average wage by occupation into a table?*/
codebook occupation

//( Step 1) Run the estimation and store the output
	sum wage if occupation==1
	return list
	
// (Step 2) Prepare the excel sheet 
	putexcel set ///
		putexcel_example.xlsx, 	///  set name of workbook here
		sheet(wage_occ)		///
		modify
// (Step 3) Label your table
	putexcel A1 = "Table: Average wage by occupation"	///
			 A2 = "Occupation"					///
	         B2 = "Average age", 				///
			 $font
			 
// // (Step 4) Put the output into the excel. I could do this:
	sum wage if occupation==1
	putexcel B3 = (r(mean))						///
			 A3 = "Professional/technical", 	///
			 $font
	sum wage if occupation==2 
	putexcel B4 = (r(mean))						///
			 A4 = "Managers/admin",				///	
			 $font
	sum wage if occupation==3
	putexcel B5 = (r(mean))						///
			 A5 = "Sales", 						///
			 $font
* 	Etc. ... Which would take A LOT of sytanx: (52 lines of syntax total)

// 	OR: We could LOOP. IT. UP:
	// Let's put in our values of our average wage by occupation:
	forval i = 1/13{
		sum wage if occupation==`i'
		local a = `i'+2				 // now, our excel will rows will be through B3-15
	putexcel B`a' = (r(mean)), 	/// 
		$font hcenter nformat(#.#)
  }
	// Ok, but what about our row labels for occupation? 
global occname "Professional/technical  Managers/admin  Sales Clerical/unskilled  Craftsmen Operatives Transport Laborers Farmers  Farm_laborers  Service Household_workers Other"
	
	/* In the following loop, we will use wordcount and word: 
	syntax: 	 wordcount(s) 
	description: gives us the number of words in s
	synax: 		 word(s, n)
	descripton:	 gives us the nth word in s */
	
	forval i = 1/13 {
		local a = wordcount("${occname}")		
		local b = word("${occname}", `i')		
		local c = `i' + 2	// start on 3rd row
	putexcel A`c' = "`b'", 	///
		$font
	}
// Putting it all together: If you want, you could put this ALL together:
// These next few lines of syntax replace the more than 50 lines of syntax previously:
	// (Step 3) Label your table:  
	putexcel D1 = "Table: Average wage by occupation"	///
			 D2 = "Occupation"					///
	         E2 = "Average age", 				///
			 $font
	forval i = 1/13 {
		local a = `i'+2				 // now, our excel will rows will be through B3-15
		local b = wordcount("${occname}")		
		local c = word("${occname}", `i')	
	sum wage if occupation==`i'		// (Step 1) run the estimation and store it
	putexcel D`a' = "`c'", $font 	// (Step 3) label your table
	putexcel E`a' = (r(mean)), 	///    (Step 4) put the stored output in excel
		$font hcenter nformat(#.#)
	}

*==================================
* (5B) Looping through columns: 
*==================================	
/* So far, all of our loops have looped through rows which is easier since rows 
are numeric values in putexcel: 
	putexcel A# = 
But what if we wanted to loop through columns? Columns take on alphabetic letters.*/
	
// prepare a new example sheet:
	putexcel set ///
		putexcel_example.xlsx, 	///  set name of workbook here
		sheet(column_example)	///
		modify
	
/* In this example, we will simply count by 5's from 0-30 and put these values
across columns */

/* We will use the command c(ALPHA).
Stata’s c-class, c(), contains the values of system parameters and settings.
c() values may be referred to but may not be assigned. For our purposes, there is
	
	c(alpha) which returns a string containing "a b c d e f g h i..". and
	c(ALPHA) which returns a string containing "A B C D E F G H I..".
	*/
	
forval i = 1/6 {
	local a = `i'*5
	local col: word `i' of `c(ALPHA)'	// creates a local that loops throught the alphabet
	putexcel `col'1 = `a'				
	}

* Examples! More examples! 

*===============================================================================
*  6) Regression output
*===============================================================================
logit married wage if race==1
ereturn list
matrix list r(table) 
// I can store a formatted version of these results in a new matrix
// The syntax for storing a matrix is matrix [name] = 
	// Here, I call my matrix Turtle:
matrix turtle = r(table)				// my matrix is a copy of r(table)
matrix turtle = turtle[1..6,1...]		// the matrix is the 1st six values
matrix list turtle

// If I just wanted the first 4 rows (beta, se, z and pvalue)
matrix results = r(table)
matrix results = results[1..4,1...]
matrix list results
// great! Now, I want to rotate it:
matrix results2 = results'
matrix list results2	// BEA-utiful. 
// Now, we can eezy-peezy put this into excel

// prepare a new example sheet:
	putexcel set ///
		putexcel_example.xlsx, 	///  set name of workbook here
		sheet(logit_output)	///
		modify
	putexcel A1 = "Table: results of logit regression, among whites", $font
	putexcel A2 = matrix(results2),	///
		names $font 	// options: putting the matrix names in and formatting font
		
*===============================================================================
* 7) Looping through excel sheets
*===============================================================================
// What if we want output for each race category? And we want it in a separate sheet?
global race "White Black Other"		// create a race global

forval i = 1/3 {
	local a = wordcount("${race}")	
	local b = word("${race}", `i')
// 1) prepare the new excel file	
	putexcel set ///
		putexcel_example.xlsx, 	/// 
		sheet("`b'")			///	This now names the sheets of the workbook "white", "black", etc:
		modify
//  2) run the regression
	logit married wage if race==`i'	
 // 3) capture the output
	matrix `b' = r(table)			// call the matrix whatever race category where looping through			
	matrix `b' = `b'[1..4,1...]'	// capture the first four rows, and transpose
 // 4) put the output into excel: 
	putexcel A1 = "Table `i': results of logit regression, among `b'" // add any labels you want
	putexcel A2 = matrix(`b'), names $font						  // put in the stored matrix
	putexcel A6 = "Note*: this output is for a subsample by race = `b'"
 }
/*Note that for the Table labeling in putexcel A1 = I loop through the table # to
automatically update and I loop through labeling the regression speficication. */

// The same as above, but with longer output: 
global race "White Black Other"		// create a race global

forval i = 1/3 {
	local a = wordcount("${race}")	
	local b = word("${race}", `i')
// 1) prepare the new excel file	
	putexcel set ///
		putexcel_example.xlsx, 	/// 
		sheet("`b'_full")			///	This now names the sheets of the workbook "white", "black", etc:
		modify
// 2) run the regression
	logit married wage tenure grade hours c_city age if race==`i'	
 // 3) capture the output
	matrix `b' = r(table)			// call the matrix whatever race category where looping through			
	matrix `b' = `b'[1..4,1...]'	// capture the first four rows, and transpose
 // 4) put the output into excel: 
	putexcel A1 = "Table `i': results of logit regression, among `b'" // add any labels you want
	putexcel A2 = matrix(`b'), names $font						  // put in the stored matrix
	putexcel A10 = "Note*: this output is for a subsample by race = `b'"
 }
 
* ★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・
*　˚*•̩̩͙✩•̩̩͙*˚＊  Yay! You're now a putexcel champ! 　˚*•̩̩͙✩•̩̩͙*˚
* ★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・・・★・・・・
