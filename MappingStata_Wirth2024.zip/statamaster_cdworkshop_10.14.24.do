/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
      
				stata your position - from data to destination 
						  presented by: bianca wirth
								  10.14.24
          
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/  

////////// master file \\\\\\\\\\
 
clear all
set more off
capture log close 
set maxvar 32767
set seed 62452501


global date 	"101424"	

									
// Bianca Global
global statamapping "C:\Users\bqw5342\OneDrive - The Pennsylvania State University\Documents\Committees\C&D\mapping in stata"

// Program & Log Directories

global data		"${statamapping}\data"	
	// where constructed data files go
global temp		"${statamapping}\temp"				
	// where output goes and cleaned data are saved
global spatial	"${statamapping}\data\shp2010"
	// where shape files are saved
global maps 	"${statamapping}\maps"
	
	
// Data Paths

global immdests "${data}\immdestclean.dta"
	// immigrant destinations cleaned file
global shp2010 "${spatial}\COUNTY_2010_US_SL050_Coast_Clipped.shp"
	// 2010 usa county shape file

	
	
	
	
	