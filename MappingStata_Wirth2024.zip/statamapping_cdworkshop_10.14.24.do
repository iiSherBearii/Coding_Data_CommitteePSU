/*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
      
				stata your position - from data to destination 
						  presented by: bianca wirth
								  10.14.24
          
*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*/  
        
  
////////////////////////////// mapping in stata \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

//// install packages we'll use for both converting the shape file and mapping

{
	ssc install spmap
	ssc install shp2dta
	ssc install geo2xy 
}


//// convert shape file + make necessary adjustments


**** convert shape file into .dta file 

{	
	spshape2dta "${shp2010}", saving(shpstata)  
/*
when we look at the data folder of your working directory, we'll see two new .dta shape files. we'll use both of those files today.
 */
}
 
 
**** making adjustments for our mapping

{
/*
we will start with the shape file that has _shp at the end. 

i am going to map on continental us counties only. to do this, i first identified the non-continental counties present in the data (alaska, hawaii, puerto rico) and drop them from the shape file. i did this by looking at the unique number of values for variable _ID, confirming that this variable is county fips codes. i then dropped the fips codes for those states. 

taking care of this step now makes our merging process easier later. 
*/

{
	use "${spatial}/shpstata_shp.dta", clear
	unique _ID
	egen OK=anymatch(_ID), values(2013 2016 2020 2050 2060 2068 2070 2090 2100 2105 2110 2122 2130 2150 2158 2164 2170 2180 2185 2188 2195 2198 2220 2230 2240 2261 2275 2282 2290 15001 15003 15005 15007 15009 46102 60010 60020 60030 60040 60050 66010 69085 69100 69110 69120 72001 72003 72005 72007 72009 72011 72013 72015 72010 72019 72021 72023 72025 72027 72029 72031 72033 72035 72037 72039 72041 72043 72045 72047 72049 72051 72053 72054 72055 72057 72059 72061 72063 72065 72067 72069 72071 72073 72075 72077 72079 72081 72083 72085 72087 72089 72091 72093 72095 72097 72099 72101 72103 72105 72107 72109 72111 72113 72115 72117 72119 72121 72123 72125 72127 72129 72131 72133 72135 72137 72139 72141 72143 72145 72147 72149 72151 72153 78010 78020 78030)
			keep if OK==0
}

/*
now that we've dropped our extraneous counties, i'm going to change the map projection. map projection is a cartographic term that roughly describes transforming a map so the figure reflects the earth's spherical surface. without this, the map will look flat, and therefore not representative of the actual proportions of the map. 

this can be done using the code below. the geo2xy command allows us to take the latitude (_Y) and longitude (_X) and select the projection we'd like to apply. i use the mercator projection, which is argued to represent local shapes most accurately. 

once this is done, i save the cleaned shape file. we will use this file later when we are ready to map.
*/	

{	
	sum _X _Y
	replace _X = 180 if _X > 180 & _X!=.
	geo2xy _Y _X, proj(web_mercator) replace
** does anyone notice anything interesting about the data when we open the data window?
	save "${spatial}\mappingcoord.dta", replace
}
 
/*
we will now turn to the second shape file that was saved as a .dta file. this file has census identifiers (in addition to latitude and longitude), allowing us to merge in our data we plan to map. 

note - you do need both the mapping coordinates file we just created and this file to merge in our census/acs data.
*/	

{
use "${spatial}\shpstata.dta"
drop if STATEFP10=="02" | STATEFP10=="15" | STATEFP10=="72"
gen fips=STATEFP10+COUNTYFP10
list fips in 1/20
destring fips, replace
keep _ID _CX _CY Remaining fips
save "${spatial}/mappingfips.dta", replace
}
}


**** merge with our data

{
/*
note - i save a temp/new data file at each step. that way anytime i want to make a new map, i can skip these first steps and jump right down to making maps!
*/

{	
	use "${spatial}/mappingfips.dta", clear
	merge 1:1 fips using "${immdests}", gen(m_1)
	drop m_1
	save "${temp}/immdestmapping.dta", replace
}
}


//// making maps

{
/*
we are going to focus on making different choropleth maps in stata. these maps use color themes as symbols to display statistical data. we will use the spmap command to do so below.

the spmap function (see help page) does provide information on creating a point map. point maps use points (circle, square, diamond, etc.) to display statistical data, and the points can be sized to display relative differences in the variable you're mapping. for example, one of the variables we'll be looking at is the percent of foreign-born residents by continental us county. i have had huge difficulties in stata with point maps, so i would recommend using r for those.

we'll start by loading the merged data, which we'll use for all the choropleth maps today.
*/

use "${temp}/immdestmapping.dta", clear

/*
first, we'll look at our continuous variables of interest. in a choropleth map, you can decide how to categorize continuous variables (often based on summary statistics). we'll take a look at them and decide how we want to break up our measures. 
*/

{
	sum fb_10 pfb_10 pchgfb, detail
	format pchgfb %15.0f
		** we do this so we can see the full number of the pchgfb values
		* browse if pchgfb>2000
		// highest value=537005057
}

/*
mapping a variable in quartiles can be a great starting point. however, when we look at these three measures, it's clear that there's often a huge difference between counties in the 99th and 100th percentile. because of this, i will add a quartile category. 

i note the values below for each variable to make it easier to map. i'll round up at the second decimal as needed. we also need to adjust the 

fb_10 (0 173 603 2607 245544 3473930)
pfb_10 (0 1.23 2.45 5.45 27.56 51.50)
pchgfb (-100 16.96 94.87 1961.60 537005057)
	* if you're interested, hyde county, nc is the one with the insane fb pop growth
*/


/* 
now that we're ready to map, we'll use that shape file we cleaned as the using file.

we'll start with mapping out the quartiles + 99th percentile of the number of foreign-born residents in 2010.

** description of options we're using **
id(_id) = variable to identify our unique identifiers, i suggest using the _id from the shape/merged files
clmethod = classification method, i use c for custom
clbreaks = numbers indicating where to cut off "classes"
fcolor = color scheme for our map
mopattern = pattern of background map
ndfcolor = fill color of empty polygons (in this case counties)
*/ 

{
	spmap fb_10 using "${spatial}\mappingcoord.dta", id(_ID) clmethod(c) clbreaks(0 173 603 2607 245544 3473930) fcolor(Purples) mosize(vvvthin) mopattern(dot) ndfcolor(gs7) title("Foreign-Born Residents in 2010") legtitle("Q1 Q2 Q3 99thPercentile Q4") 
}
	
/*
after making the map, don't close the window! we can save the map using the graph export command and send it to our maps folder. 

it is easiest to save the graph right after creating it using the graph export option name("graph"), as stata automatically uses that name for the window that opens the map. we can use the quality option to set the visual quality of the map (100 is the upper limit, quality only so good in stata tbh).
*/

{
	graph export "${maps}/fb2010_map.jpg", quality(100) name("Graph") replace
}

/*
now let's create maps of the percent of foreign born residents in 2010 and the percent change in foreign born residents from 1980-2010. we can use help spmap to pick a new color scheme. 

i added other options like the size of the line for the county boundaries (osize) and the pattern of the line (osize), but the difference isn't visible.
*/

{
	spmap pfb_10 using "${spatial}\mappingcoord.dta", id(_ID) clmethod(c) clbreaks(0 1.23 2.45 5.45 27.56 51.50) fcolor(Rainbow) osize(medthin) osize(longdash) mosize(vvvthin) mopattern(dot) ndfcolor(gs7) title("Percent Foreign-Born Residents in 2010") legtitle("Q1 Q2 Q3 99thPercentile Q4") 
	graph export "${maps}/pfb2010_map.jpg", quality(100) name("Graph") replace

	spmap pchgfb using "${spatial}\mappingcoord.dta", id(_ID) clmethod(c) clbreaks(-100 16.96 94.87 1961.60 537005057) fcolor(Pastel2) mosize(vvvthin) mopattern(dot) ndfcolor(gs7) title("Percent Change Foreign-Born Residents 1980-2010") legtitle("Q1 Q2 Q3 99thPercentile Q4") 
	graph export "${maps}/pfb2010_map.jpg", quality(100) name("Graph") replace
}

/* 
finally, we're going to create a map of a categorical variable. i created individual binary measures for four mutually exclusive categories of immigrant destinations (johnson and lichter 2016). 

we can code those as one variable and use the clmethod option u for unique, which takes the unique values of the variable we're mapping and places them into separate categories.

 with a categorical variable, we no longer need the clbreaks() option to map.
*/ 

{
	sum estabdest newdest emergdest otherdest
	gen destcat=0
	replace destcat=1 if estabdest==1
	replace destcat=2 if newdest==1
	replace destcat=3 if emergdest==1
	replace destcat=4 if otherdest==1
	
	spmap destcat using "${spatial}\mappingcoord.dta", id(_ID) clmethod(u) fcolor(Spectral) mosize(vvvthin) mopattern(dot) ndfcolor(gs7) title("Immigrant Destinations, 1980-2012") legtitle("Destination Type") 
	graph export "${maps}/immdest_map.jpg", quality(100) name("Graph") replace
}

/*
notice that the legend is not well defined. for the graphs we've  made up to this point, the variables were labeled, which made the map easier to interpret. we can add labels to the destination categories variable we just created to ensure our legend is clear. 
*/

{
	tab destcat
	label variable destcat "immigrant destinations"	
	label values destcat destlabels
	label define destlabels 1 "established - 68" 2 "new - 143" 3 "emerging - 222" 4 "other - 2676"	
	tab destcat, m
}

/*
now let's make our map.
*/	

{
	spmap destcat using "${spatial}\mappingcoord.dta", id(_ID) clmethod(u) fcolor(PuOr) mosize(vvvthin) mopattern(dot) ndfcolor(gs7) title("Immigrant Destinations, 1980-2012") legtitle("Destination Type") 
	graph export "${maps}/immdest_map.jpg", quality(100) name("Graph") replace
}
}


















