********************************************************************************
********************************************************************************
*Author:			Megan Evans
*Topic:				SOC596 - Making Figures in Stata
*Date Created:		04/15/2021

*E-Mail:			mme5163@psu.edu
*Please contact me with questions. I'm happy to hop on a Zoom with you to troubleshoot any figure problems you might have!
********************************************************************************
********************************************************************************
global data "C:\Users\mme5163\OneDrive - The Pennsylvania State University\Others\Files for Making Figure"				

/*

Beyond finalized figures for publication or presentations, figures are an important part of the data exploration process to aid in your own understanding of the data and your story.

Data Files we are working with

1) Homelessness Data at the State-Level in 1933 and 2018

	homelessness.dta


*/

/*1) Schemes - There are a number of different graphic schemas. These determine the overall default layout of your figures. Have fun exploring them and deciding which one you like best. If you have a favorite, you can always tell Stata to permanently remember a new default scheme.

e.g.
	set scheme burd, permanently 
*/
set scheme burd


*2) Graph title, axis, labels, etc. options.

*Let's say we are interested in understanding what homelessness looked liked in 2018 compared to 1933
use "${data}\Data\homelessness.dta", clear	

		
*First let's just look at a basic scatter plot
scatter homeR1 homeRJ3

*Now, let's add some basic titles axis labels and marker labels

scatter homeR1 homeRJ3,  ///
	mlabel(statename) /*Add marker label*/ ///
	ytitle("2018 Rate", size(small)) /*Add y-axis title*/ ///
	xtitle("1933 Rate", size(small)) /*Add x-axis title*/ ///
	title("Homelessness Rate by State, 1933 and 2018")  /*Add figure title*/ ///
	note("Rate per 10,000 People") /*Adds figure note*/ ///
	name(homeless_sct, replace) /*Name the Stata graph*/ 
		
* Our above graph is misleading, we want a consistent Y and X axis, so let's tell Stata.
	
scatter homeR1 homeRJ3, ///
	mlabel(statename) /*Add marker label*/ ///
	ytitle("2018 Rate", size(small)) /*Add y-axis title*/ ///
	yscale(range(0 200)) /*Specifies y-axis range*/ ///
	ylabel(0(50)200) /*Specifies y-axis interval tick labels*/ ///
	xtitle("1933 Rate", size(small)) /*Add x-axis title*/ ///
	title("Homelessness Rate by State, 1933 and 2018")  /*Add figure title*/ ///
	note("Rate per 10,000 People") /*Adds figure note*/ ///
	name(homeless_sct, replace) /*Name the Stata graph*/ 
	

*Export the Figure
graph export "${data}\homelessness_scatterplot.pdf", as(pdf) name(h_3318) replace


*2) Histograms
hist homeR1, freq xtitle("2018") name(h2018, replace) 
hist homeRJ3, freq xtitle("1933") name (h1933, replace)

*3) Graph Combine
graph combine h1933 h2018, row(1) ycommon xcommon title("Distribution of Homelessness Rate, 1933 and 2018")


*4) Twoway Graphs
*Note the jitter option
twoway ///
scatter homeR1 nonwhitep1, jitter (7) || ///
lfit homeR1 nonwhitep1 || ///
scatter homeRJ3 nonwhitep3, jitter (7) || ///
lfit homeRJ3 nonwhitep3, ///
legend(label(1 "2018") label(2 "2018") label(3 "1933") label(4 "1933")) ///
ytitle("Homelessness Rate, per 10,000") ///
xtitle("Percentage of Non-White Population") ///
title("Homelessness Rates by Percentage of Non-White Population")
name(hrace, replace)


/*

Here is an example using the above commands of a few figures I have recently made in the last few weeks in the process of me exploring my data for a paper I am writing.

Data Files we are working with

1) Neighborhood Undesirability in Chicago

	cas.dta


*/

*Open Data
import delimited "C:\Users\mme5163\OneDrive - The Pennsylvania State University\CAS\R Programs\cas_com_210330.csv", clear

*Create histograms of Neighborhood Undesirability for Overall sample and by each racial and ethnic group.
hist p_nc, xtitle("Percentage of Full Sample") name(nc, replace)
hist p_nc_b, xtitle("Percentage of Black Sample") name (ncb, replace)
hist p_nc_w, xtitle("Percentage of White Sample") name(ncw, replace)
hist p_nc_h, xtitle("Percentage of Hispanic Sample") name(nch, replace)

*Combine the histograms to better examine them together.
graph combine nc ncb ncw nch, row(2) ycommon xcommon title("Neighborhood Undesirability")
*Export graph
graph export "${logs}/pneighreps_hist.pdf", as(pdf) replace


*Create scatterplots with linear fit for neighborhood undesirability by each racial and ethnic group across neighborhood disadvatnage
twoway scatter p_nc_w disadvantage, jitter (7) || lfit p_nc_w disadvantage || scatter p_nc_b disadvantage, jitter (7) || lfit p_nc_b disadvantage ||  scatter p_nc_h disadvantage, jitter (7) || lfit p_nc_h disadvantage, legend(label(1 "White Sample") label(2 "White Sample") label(3 "Black Sample") label(4 "Black Sample") label(5 "Hispanic Sample") label(6 "Hispanic Sample") size(small)) ytitle("Neighborhood Undesirability", size(small)) xtitle("Concentrated Disadvantage", size(small)) title("Neighborhood Undesirability and Concentrated Disadvantage", size(medium)) name(repdis, replace)
*export graph
graph export "${logs}/neighrepsdis_scatter.pdf", as(pdf) replace

*Create scatterplots with linear fit for neighborhood undesirability by each racial and ethnic group across neighborhood racial concentration

*Across percent black in neighborhood 
twoway scatter p_nc_w percentblack, jitter (7) || lfit p_nc_w percentblack ||scatter p_nc_b percentblack, jitter (7) || lfit p_nc_b percentblack ||  scatter p_nc_h percentblack, jitter (7) || lfit p_nc_h percentblack, legend(label(1 "White Sample") label(2 "White Sample") label(3 "Black Sample") label(4 "Black Sample") label(5 "Hispanic Sample") label(6 "Hispanic Sample") size(small)) ytitle("Neighborhood Undesirability", size(small)) xtitle("Percentage of Black Residents")  name(reppblack, replace)

*across percent white in neighborhood 
twoway scatter p_nc_w percentwhite, jitter (7) || lfit p_nc_w percentwhite || scatter p_nc_b percentwhite, jitter (7) || lfit p_nc_b percentwhite ||  scatter p_nc_h percentwhite, jitter (7) || lfit p_nc_h percentwhite, legend(label(1 "White Sample") label(2 "White Sample") label(3 "Black Sample") label(4 "Black Sample") label(5 "Hispanic Sample") label(6 "Hispanic Sample") size(small)) ytitle("Neighborhood Undesirability", size(small)) xtitle("Percentage of White Residents")  name(reppwhite, replace)

*Across percent hispanic in neighborhood
twoway scatter p_nc_w percenthispanic, jitter (7) || lfit p_nc_w percenthispanic || scatter p_nc_b percenthispanic, jitter (7) || lfit p_nc_b percenthispanic ||  scatter p_nc_h percenthispanic, jitter (7) || lfit p_nc_h percenthispanic, legend(label(1 "White Sample") label(2 "White Sample") label(3 "Black Sample") label(4 "Black Sample") label(5 "Hispanic Sample") label(6 "Hispanic Sample") size(small)) ytitle("Neighborhood Undesirability", size(small)) xtitle("Percentage of Hispanic Residents")  name(repphisp, replace)

*Combine the graphs to more easily view together
grc1leg reppwhite reppblack repphisp, leg(reppblack) rows(1) xcommon ycommon name(reppraces, replace)  title("Neighborhood Reputation by Neighborhood Racial Composition", size(medsmall)) altshrink
graph export "${logs}/neighrepsrace_scatter.pdf", as(pdf) replace


