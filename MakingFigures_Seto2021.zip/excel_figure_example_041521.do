********************************************************************************
** Title: EXPORTING MATRICES TO EXCEL FOR ADDITIONAL FORMATTING INTO TABLES AND FIGURES

* Creation Date: 	04.15.21
* Last Edited:   	04.15.21
* Created by:	 	Chris Seto
* Last Edited by:	Chris Seto
********************************************************************************


********************************************************************************
** STARTING YOUR DO FILE
********************************************************************************
clear // clears any open datasets
clear matrix
clear mata //these are good habits too
set more off, permanent

* Tell STATA where on your computer to find your data using the "cd" command
cd "C:\Users\chris\Box\random stuff\figures_workshop_041521"  

* OPEN THE STATA DATA SET
use CSAF_2018.dta, clear
numlabel, ad

* DESCRIBE 
describe qn20k

* WHAT DOES THIS DISTRIBUTION LOOK LIKE?
tab qn20k

//let's drop those missing people
recode qn20k (-1=.), gen(ghosts)


*LET'S SAY FOR MY RESEARCH PAPER, I WANT TO SHOW THE DISTRIBUTION OF THIS VARIABLE
prop ghosts

*IT WOULD BE GREAT IF I COULD GET THOSE NUMBERS INTO EXCEL! BUT IF I MANUALLY COPY THEM, I MIGHT MAKE A MISTAKE. ALSO, IT WILL TAKE A LONG TIME.
*CAN I MAKE STATA DO IT FOR ME?

return list

*LOOKS LIKE THERE IS A MATRIX CURRENTLY STORED IN MEMORY CALLED "r(table)". What is in there?

matrix list r(table)

*YIKES. THAT'S A LOT OF NUMBERS THAT I DON'T NEED. ALSO THE MATRIX IS SIDEWAYS. LET'S FIX THAT UP

matrix result = r(table) //take the results table and save it as a new matrix called "result"

matrix result = result[1..6,1...]' //crop "result" to just the first 6 rows. Keep all the columns. The apostrophe transposes, because Stata saves it sideways for some reason.

matrix list result //let's see what that looks like.

*GREAT, NOW CAN WE PUT THAT IN EXCEL?

*FIRST, TELL STATA WHAT WORKBOOK AND SHEET YOU WANT TO USE:
putexcel set RESULTS.xls, sheet(figure1) modify //modify is important - lets you format the sheet and then re-export without wiping everything clean

*THEN, TELL STATA WHERE ON THE SHEET YOU WANT IT TO GO. Option "names" keeps row and col names (useful) and the other options are formatting. 
putexcel A1 = matrix(result), names nformat(number_d2) hcenter //send the table to wherever you want it in the sheet (this one puts the top left corner of the matrix in cell A1).

*******************************************************************************
*STATA BREAK! LET'S GO WORK IN EXCEL
*******************************************************************************



