/*
Session 5 – Led by Alexander Chapman
	o	Visualizing data
				Producing a histogram
				Scatterplots
				Set scheme
				Adjusting graphs
				•	Title
				•	Axis titles
				•	Note
				•	Change marker size
				•	More
				Exporting Figures
*/

//What is the value of visualizing data? 
	*Illustrate complex ideas accurately and quickly
	*Summarize variable(s) and relationships between them
	*View distribution of variables - people who prefer visualization to looking at numbers in a tabulation or table
	*Quickly see patterns in data

//Is Stata the best way to visualize data?
	*Stata is a good* way to visualize data - Excel, R, others. Software for visualizing your data should be based on project needs. Authors use Stata to produce figures at major journals across social science disciplines.
	
//Examples of common visualizations?
	*https://www.trentonmize.com/software/cleanplots
	
//Visualizations have many options and more often than not, you'll have to go hunting online for nuance involved with whatever you are graphing at the time. Also reach out to others for help if you are stuck!

//Open dataset
use "C:\Users\alexc\Downloads\CodingGroupExampleData.dta", clear //Harmonized and recoded NHANES (National Health and Nutrition Examination Survey) data 2006-2010

//Five variables of in this dataset: dep (measure of depression); sni (measure of social integration); age (measure of age in years); bmi (body mass index); race (race/ethnicity)

tab dep, m //Dichotomous depression variable, 1 indicates that respondent meets threshold on depression inventory and is likely depressed. 0 means that respondent does not meet the threshold and is probably not depressed. This is scored using responses to the PHQ-8 (8 question Patient Health Questionaire).

tab sni, m //Categorical ordinal indicator of social integration. 3 meaning most integration and 0 meaning least. SNI (Social Network Index) is a common way to measure social integration.

tab race, m //Categorical 1 = NH White, 2 = NH Black, 3 = Hispanic

tab age, m //Age in years of respondent
sum age, detail //Since this is a continuous variable, sum shows the variable distribution better than tab.

tab bmi, m //body mass index
sum bmi, detail

*************************************************************************
***------------ SCHEMES FOR GRAPH VISUALIZATION IN STATA -----------*****
*************************************************************************

//Q & A
/* 
Question 1: What is a scheme?
Answer: Schemes determine the overall outlook of a graph in Stata - enter "help scheme" in the command line for more details.
You can customize almost everything about a graph in Stata. Rather than typing all of that information using options each time you graph a figure, you can set a scheme.

Question 2: What are the scheme options and how do I find more of them?
Answer: Stata comes with several options already installed. Use "graph query, schemes" to see what schemes are installed. Typically searching online for the scheme(s) you would like works well. Examples upcoming!

Question 3: How do you use a scheme?
Answer: You can either set the scheme or call a scheme using an option. Examples upcoming.
*/

graph query, schemes

//Example 1a - Set Scheme
set scheme s2color //Using this command sets the scheme as s2color for the remainder of the current Stata session. s2color is the default Stata graphing scheme. If you do not set a scheme, this is what Stata will use.

hist age, percent //sidenote - notice the bunching of age around certain numbers, sometimes binning data helps deal with this.

hist bmi, percent //I like percent to provide information about but other options may be more suitable for your research questions and variables such as frequency

hist bmi, freq 

set scheme s1mono, perm //The permanent or "perm" option sets the scheme permanently for future Stata sessions. I recommend doing this if you find a scheme that you will use regularly.

twoway scatter bmi age //kind of ugly for the gaps between values here

twoway scatter bmi age, jitter(7) //jitter adds random noise that improves the look of the graph and shows the figure with less precision which is more emblematic of reality - consider age in this case its a continuous variable you can be 45 years 3 months 6 days 2 hours 14mins 27seconds etc old, but our data are recorded at year only which means there are gaps between 45 and 46 that do not actually exist. Jitter fills those gaps

twoway lfitci bmi age //linear fit between the variables with 95% confidence intervals

twoway (scatter bmi age, jitter(7)) (lfitci bmi age) //both figures overlayed - notice less precision on the right with less observations

//Example 1b - Calling a scheme with as an option

hist age, percent scheme(cleanplots) //Userwritten scheme by Trenton Mize. Also good option for figures generally see https://www.trentonmize.com/software/cleanplots (if not installed) and "help cleanplots" (if installed) - This is my personal favorite.

hist age, percent scheme(economist) //Similar scheme to economist magazine - see help economist

hist age, percent scheme(plotplainblind) //Colorblind scheme though many are

set scheme cleanplots, perm //Setting clean plots as the permanent scheme

twoway (scatter bmi age, jitter(7)) (lfitci bmi age) //remember this figure as we will be using it later

//Associations between variables with categorical predictors - bar charts
	*NOTE not recommended to include multiple variables unless you have theoretical motivation for looking at these associations/interactions. Checking interactions between "random" variables may reveal false positives. 
	*Let theory motivate your tests*
cibar dep, over1(race) //cibar does not work with typical graph options details on how to use graph editor later. Also does not work well over a continuous variable, better over categories
cibar dep, over1(sni) over2(race) 

//Curvilinear associations with continuous predictors - Lowess or Loess (Locally weighted scatterplot smoothing or Locally weighted smoothing) Make a smooth line through a plot to see relationship between coninuous or perhaps ordinal variables, but works best with continuous. More here -> https://www.statisticshowto.com/lowess-smoothing/
	*Maybe the association between variables is not a straight line. Or maybe you're concerned that the relationship between two variables might be nonlinear and you'll need to adjust them.
	lowess bmi age // no jitter notice the fixed gaps between ages
	lowess bmi age, jitter(7) // much better and more realistic appearance - notice the weak negative association
	gen age_sq=age*age //making age-squared variable. Lots of social findings with age are nonlinear due to life course trajectories - eg most autonomous in middle ages and most dependent when youngest and oldest on average.
	lowess bmi age_sq, jitter(7) // see the change in scale - not much evidence of curvilinear relationship 
	lowess age_sq age, jitter(7) // this makes sense 40*40 = 1600. We see an upward curve.
	lowess sni age, jitter(7)

*************************************************************************
***------------------------ ADJUSTING GRAPHS -----------------------*****
*************************************************************************

//There are three ways to change how graphs appear (1) schemes, (2) options, and (3) graph editor
	*We have already covered schemes above, we will focus on options and then lastly graph editor.
	
//Example 1: Options - We have a scatterplot that we really like with our scheme, but we want to change something small like the title, axis titles, marker size, legend labels, or a color. All of these are often affected by schemes except text.
	*We really liked our scatterplot of age and bmi except we wish it had some titles
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) jitter(7)) (lfitci age bmi) //Overall title
	
	*Okay maybe we should add a note for NHANES
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) note(Analysis Based on NHANES data 2006-2010) jitter(7)) (lfitci age bmi) //Overall title and Note

	*Oh and a y-axis label
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) note(Analysis Based on NHANES data 2006-2010) ytitle(Age) jitter(7)) (lfitci age bmi) //Overall title, Y-Axis Title and Note
	
	*And the markers are kind of large, lets use small ones
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) note(Analysis Based on NHANES data 2006-2010) ytitle(Age) msize(vtiny) jitter(7)) (lfitci age bmi) //Overall title, Y-Axis Title, Note, and Marker size
	
	*Actually that was too small
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) note(Analysis Based on NHANES data 2006-2010) ytitle(Age) msize(tiny) jitter(7)) (lfitci age bmi) //Overall title, Y-Axis Title, Note, and Marker size

//Example 2: Graph Editor - We have a figure that we mostly like, but we want to change something or even several things and have no clue what the options are or how to specify them. In the example, I'm going to hide the shading for the confidence intervals.
		*But is this reproducible? BE SURE TO RECORD - SEE FOLLOWING EXAMPLE
	twoway (scatter age bmi, title(Age and BMI Scatterplot with Linear Fit) note(Analysis Based on NHANES data 2006-2010) ytitle(Age) msize(tiny) jitter(7)) (lfitci age bmi)
	
	graph save "Graph" "C:\Users\alexc\Downloads\AgeBMI.gph", replace //Saving a copy as .gph makes it easier to reopen and edit in Stata -especially important for figures that take a long time for Stata to produce.

	//How do I use the recording to reproduce my work?
		*Use "graph play recordingname.grec"
	
	graph use "C:\Users\alexc\Downloads\AgeBMI.gph" //unaltered graph - note that if you enable graph editor you cannot enter commands into Stata
	
	graph play "C:\Users\alexc\Downloads\Session5.grec" //replays the saved recording in graph editor - will work on new graphs as well - say you would want to have this same visualization on different variables/data the recording will work in those cases as well
	
*************************************************************************
***------------------------ EXPORTING FIGURES ----------------------*****
*************************************************************************

graph export "C:\Users\alexc\Downloads\AgeBMI_v2.tif", as(tif) name("Graph") replace //Saving in a file type that you can open outside of Stata such as .pdf .tif .jpeg etc will be important for submitting figures to journals, presentations or otherwise exporting for use.	
