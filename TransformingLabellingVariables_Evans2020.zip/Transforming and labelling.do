**Title: Coding Committee Transforming & Labelling Lesson
**Author: Rachel McNealey
**Created: 11/19/2020
**Edited: 11/20/2020


clear
capture log close


cd "C:\Users\Rachel\Box Sync\Projects\Workplace Deviance\Data\NYS"
use Wave7Data.dta

numlabel, ad

*Creating categorical var from continuous
tab Y7_464, m
clonevar carryweapon=Y7_464
tab carryweapon
replace carryweapon=. if Y7_464==-1
recode carryweapon (2/10=1) (12/30=2) (35/65=3)(100/365=4)
tab carryweapon


*Transforming dichotomous var into binary dummy
tab Y7_290, m
clonevar children = Y7_290
replace children=. if Y7_290==-1
replace children=0 if Y7_290==1
replace children=1 if Y7_290==2
tab children Y7_290, m


*Generating dummies from a categorical var
tab Y7_3, m
tab Y7_3, gen (r)

tabstat r1 r2 r3 r4 r5 r6

tab r1
rename r1 white
tab white



*Collapsing a categorical var into a dummy var
clonevar carryweapon_d=carryweapon
recode carryweapon_d (2/4=1)
tab carryweapon_d carryweapon



*Creating & assigning labels

tab children


label define binary 0 "No" 1"Yes"
label define offendingcat 0 "Non-offender" 1 "Low-level" 2 "Moderate" 3 "Frequent" 4 "High-level"


label values children binary
tab children

label values carryweapon offendingcat 
tab carryweapon

label values carryweapon_d binary 
tab carryweapon_d

label list

label drop binary