*
clear*

***********************************WELCOME!*************************************
*This is your do file for "Imputation Tips & Tricks"
*By: Rebecca Bucci & Ted Greenfelder
*November 1st 2019
*Sponsored by the Population Research Institute & The Department of Sociology & Criminology at Penn State
*******************************************************************************
/*Follow us on Twitter

@RebeccaBucci21
@greenfelder

Example dataset: Pathways to Desistance 
The dataset is described here: https://www.pathwaysstudy.pitt.edu/index.html
It can be downloaded in its entirety thorugh ICPSR: https://www.icpsr.umich.edu/icpsrweb/ICPSR/series/260 
(See Slide 5 for more information)
*/

*https://psu.box.com/s/jcb6108icxxyiw0fr22l4cmb8dq541lx
*cd "C:\Users\User\Box\Imputation Tips & Tricks (Coding & Data Management Working Group)"

**Directory for Google Drive
//  //

 
 cd "C:\Users\User\Desktop"
 use "Example Dataset.dta",clear
* use ("your_directory\Example Dataset.dta")

*Load the file & look through some variables of interest
codebook
desc 

*Q1 : How many total observations exist?


*Check out the missing!
misstable sum, all
misstable patterns male location age usborn ranawayfreq anxiety hostility marriedparents headinjury famarrested famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq offend gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample
misstable tree male location age usborn ranawayfreq anxiety hostility marriedparents headinjury famarrested famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq offend gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample

misstable sum, gen(miss_)

*An alterantive way to do this is with a loop
foreach var in male location age usborn ranawayfreq anxiety hostility marriedparents headinjury famarrested famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq offend gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample {
egen `var'missing = rmiss(`var')
}

ssc install mdesc
mdesc

*Q2 : What variable has the most missing? Second most missing?


*To Check if any cases have a particulatly large amount of item missing
egen itemmissing = rmiss(_all)
tab itemmissing


*Q3 : What CASEID has the most missing?
gsort -itemmissing



********************************************************************************
*******************************Imputing Your Data*******************************
********************************************************************************
*(See Slides #9-10)

* Multiple Imputation by Chained Equations (MICE)

mi set wide

mi register imputed CASEID male offend location age ranawayfreq anxiety hostility marriedparents headinjury famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample

mi impute chained (pmm, knn(5)) ranawayfreq anxiety hostility friends prop_friendsarrested  pmon policepj offendfreq offendvariety resistspeers impulsecontrol selfesteem age  (logit) offend male location marriedparents headinjury famjail momalcoholic bullied gang lowSES missexample, add(3) rseed(1) noi

beep

*Q4 : Why did the imputation fail?
*(See Slide #11)

********************************************************************************
*Try it again

use "Example Dataset.dta",clear
mi set wide
mi register imputed CASEID male location age ranawayfreq anxiety hostility marriedparents headinjury famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample

mi impute chained (pmm, knn(5)) ranawayfreq anxiety hostility friends prop_friendsarrested  pmon policepj offendfreq offendvariety resistspeers impulsecontrol selfesteem age  (logit) male location marriedparents headinjury famjail momalcoholic bullied gang lowSES missexample, add(3) rseed(1) noi

beep

*If 2 measures are too correlated to impute (like a dichotomous variable for offending is perfectly predicted by the frequency of offending) you can generate after imputation based on the imputed offending frequency variable
gen offended=.
mi register passive offended
mi passive: replace offended=0 if offendfreq==0
mi passive: replace offended=1 if offendfreq>0 

save "ImputationExampleData_01Nov2019_MICE.dta",replace


*Alternative Strategy - Multivariate Normal Imputation (MVNI)
help mi_impute_mvn
use "Example Dataset.dta", clear

mi set wide

mi register imputed CASEID male location age ranawayfreq anxiety hostility marriedparents headinjury famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample

mi impute mvn age anxiety hostility marriedparents famjail momalcoholic friends prop_friendsarrested pmon policepj offendfreq gang offendvariety lowSES resistspeers impulsecontrol missexample = male location usborn ranawayfreq headinjury bullied, add(3) rseed(1)

gen offended=.
mi register passive offended
mi passive: replace offended=0 if offendfreq==0
mi passive: replace offended=1 if offendfreq>0 

save "ImputationExampleData_01Nov2019_MVNI.dta",replace

********************************************************************************
************************Return to Imputed Data of Choice************************
********************************************************************************

use "ImputationExampleData_01Nov2019_MVNI.dta", 	clear
use "ImputationExampleData_01Nov2019_MICE.dta", 	clear

********************************************************************************
**************************Some Post Imputation Diagnostics**********************
********************************************************************************

*Compare means, ranges, frequencies in imputed & original data

*ssc install doesn't play well
findit midiagplots

*The diagplots command compares the imputed values with the observed ones, so implausible imputed values may be detected before the primary analysis. 
midiagplots pmon, more m(1 2 3) 

*Use mean for continuous variables 
mi estimate: mean friends

*Use proportion for categorical variables
mi estimate: proportion bullied

*Q5 : Are there significant differences between imputed and original data on certain variables?

*We used this code above - but because we didn't use these in our imputation (of course) we recreate these variables for diagnostic purposes
foreach var in male location age usborn ranawayfreq anxiety hostility marriedparents headinjury famarrested famjail momalcoholic friends prop_friendsarrested bullied pmon policepj offendfreq offend gang offendvariety lowSES resistspeers impulsecontrol selfesteem missexample {
egen itemmissing_`var' = rmiss(`var')
}

mi estimate: ttest offendfreq, by(itemmissing_pmon)

mi estimate: regress pmon itemmissing_pmon
*Those that are imputed on parental monitoring have signficantly lower levels of parental monitoring than those who are not imputed on parental monitoring

egen itemmissing = rmiss(_all)
tab itemmissing

mi estimate: regress offendfreq itemmissing

*Q6: Are those with missing data signficantly more likely to have higher rates of offending frequency?


********************************************************************************
**********************Descriptives with Imputed Data****************************
********************************************************************************

*Flags observations in the original data that have missing values
tab _mi_miss

*Flags the imputation number (i.e. dataset number m)
tab _mi_m

*Post imputation missing summaries

mi misstable summarize

mi misstable patterns

********************************************************************************
***************************Understanding Imputation*****************************
********************************************************************************

*Return to Powerpoint Slides (See Slide #15)

********************************************************************************
**********************Bivariate Analyses w/ MI Data*****************************
********************************************************************************

*More T-tests with imputed data

mi estimate: regress offendfreq male

*Q6 : Are there differences between males and females on prevalence of head injuries?


*Q7 : Are there differences between males and females on being bullied?



********************************************************************************
***********************Survey Design Adjustments with Imputed data**************
********************************************************************************

*How to use survey weights with imputation

*mi svyset 'Primary Sampling Unit' [w='Weight'], strata ('Strata') fpc ('Finite population correction')

*Then you would continue to use mi estimate: normally

********************************************************************************
**********************Imputation Options Comparison*****************************
********************************************************************************
ssc install estout

*Check to see where estimates are stored in Stata

logit bullied usborn ib16.age lowSES pmon

*see generated matricies
return list
ereturn list
mat list r(table)
 
mat coefs_temp = e(b)
mat coefs = coefs_temp'
mat list coefs 
 
est clear
clear matrix
cls

local i = 3
local est = 1
forvalues j = 1(1)`i'{
use "ImputationExampleData_01Nov2019_MVNI.dta", clear
	mi extract `j'
		eststo SimpleModelMVN_`est': 	quietly logit bullied usborn age lowSES pmon
			mat list e(b)
local `++est'
}

local i =3
local est = 1
forvalues j = 1(1)`i'{
use "ImputationExampleData_01Nov2019_MICE.dta", clear
	mi extract `j'
		eststo SimpleModelMICE_`est':	quietly logit bullied usborn ib16.age lowSES pmon
			mat list e(b)
local `++est'
}

use "ImputationExampleData_01Nov2019_MVNI.dta", 	clear
mi estimate: logit bullied usborn age lowSES pmon
mat list e(b_mi)

use "ImputationExampleData_01Nov2019_MICE.dta", 	clear
mi estimate: logit bullied usborn i.age lowSES pmon
mat list e(b_mi)

esttab SimpleModelMVN_*  SimpleModelMICE_* using "SimpleComparison.csv",  mtitles("MVN_1" "MVN_2" "MVN_3" "MICE_1" "MICE_2" "MICE_3" ) nonum  se staraux  replace 


* Q7 : Do the estimates look similar?


********************************************************************************
***********************When Stata Doesn't Support the Command*******************
********************************************************************************

*If there is no other option - Do it by "hand"!
mi xeq: regress offendfreq lowSES bullied male ib16.age impulsecontrol location headinjury pmon gang

*For MVN 
mi xeq: regress offendfreq lowSES bullied male age impulsecontrol location headinjury pmon gang


*Combine the coefficients for your favorite variable!

*Q8 : What number did you get for lowSES? How about impulse control?



*Check it against mi estimate command

mi estimate: regress offendfreq lowSES bullied male ib16.age impulsecontrol location headinjury pmon gang


*Q9 : Do the estimate match by 'hand' and with MI estimate?


*But wait! An easier way to automate this process...Loop through the procedure


********************************************************************************
**********************Imputation Loop for Rubin's Rules*************************
********************************************************************************

*NOTE: All of the loop must be selected, from the first local to the last `}' 

*create an excel file
putexcel set "OffendingFrequency.xls", replace

*Generate a lot of local macros. Some say too many.
local i = 3					
local t = 1	
local n = 2
local c = 1
local m = 2
local z = 15	
local f = 2


forvalues j = 1(1)`i'{
*use "C:\Users\rbucc\Box\Macbook Pro Files\MCS Puberty Paper\MCS_PT_Imputed_Change_female_071219.dta", clear
use "ImputationExampleData_01Nov2019_MICE.dta", clear

*extract each dataset that was gererated through imputation
mi extract `j'
*label rows with variable names
putexcel A1=("Model") B1=("Variable") C1=("Coef") D1=("SE") E1=("Variable_Order") A`m':A`z'=(`t') B`f'=("LowSES") B`++f'=("Bullied") B`++f'=("Male") B`++f'=("Age14") B`++f'=("Age15") B`++f'=("Age16") B`++f'=("Age17") B`++f'=("Age18") B`++f'=("ImpulseControl") B`++f'=("Location") B`++f'=("HeadInjury") B`++f'=("ParentalMonitoring") B`++f'=("GangStatus") B`++f'=("Constant")
*The actual regression we need to loop
quietly regress offendfreq lowSES bullied male ib16.age impulsecontrol location headinjury pmon gang

*saves the coeficients of the model from stata's r(table) matrix
mat coef_temp = r(table)
*using the  ' at  the end of the matrix transposes it
mat coef= coef_temp[1..2,1...]'
*prints r(tables) to double check, can be removed					
mat list coef
*Stores the matrix output in an excel sheet 
putexcel C`n'=matrix(coef)

*Index the macros as needed
local ++t
local n = `n'+14
local c = `c'+14
local m = `m'+14
local z = `z'+14
local ++f
 }


 
import excel "OffendingFrequency.xls", sheet("Sheet1") firstrow clear
browse
save "OffendingFrequency.dta", replace

use "OffendingFrequency.dta", clear
browse
reshape wide Coef SE, i(Variable) j(Model)
replace Variable_Order  = 1 if Variable=="LowSES"
replace Variable_Order  = 2 if Variable=="Bullied"
replace Variable_Order  = 3 if Variable=="Male"
replace Variable_Order  = 4 if Variable=="Age14"
replace Variable_Order  = 5 if Variable=="Age15"
replace Variable_Order  = 6 if Variable=="Age16"
replace Variable_Order  = 7 if Variable=="Age17"
replace Variable_Order  = 8 if Variable=="Age18"
replace Variable_Order  = 9 if Variable=="ImpulseControl"
replace Variable_Order  = 10 if Variable=="Location"
replace Variable_Order  = 11 if Variable=="HeadInjury"
replace Variable_Order  = 12 if Variable=="ParentalMonitoring"
replace Variable_Order  = 13 if Variable=="GangStatus"
replace Variable_Order  = 14 if Variable=="Constant"


*STEP 1 - Pool coefficients
egen poolcoef = rowmean(Coef*)

*STEP 2 - Pool Standard Errors
egen poolse = rowmean(SE*)

*STEP 3 - Estimate variance - var z = 1/(n-3)
gen var = 1/(1354-3)

*STEP 4 - Generate the within imputation variance = (1/m)(sum of the se's squared)
gen withinvar = (1/3)*((SE1^2)+(SE2^2)+(SE3^2))

*STEP 5 - Generate the between imputation variance = 1/n-1((poolcoef - estimate from dataset1^2) + poolcoef - estimate from dataset2^2....)
gen betweenvar = (1/(3+1))*((poolcoef-Coef1)^2)+((poolcoef-Coef2)^2)+((poolcoef-Coef3)^2)

*STEP 6 - Generate the total variance which =  within+between+(between/number of datasets)
gen totalvar = withinvar+betweenvar+(betweenvar/3)

*STEP 7 - Create the appropriate standard errors
gen correctse = sqrt(totalvar)

*NOTE: Examine how combined standard errors before adjustment & pooled standard errors are similar, but corrected standard errors are slightly smaller when adjusted

*STEP 8 - Generate t value for assessing signficance
gen tvalue = poolcoef / correctse

*FINAL STEP - Examine final Coefficients and final standard errors 

keep Variable poolcoef correctse tvalue Variable_Order

sort Variable_O
browse

* Q10 : Do the estimate match by 'hand', with the loops and with MI estimate?


********************************************************************************
**********************************Now You Try!**********************************
********************************************************************************
*(See Slide #24)

***	Loop for Logit

*Pick your favorite explanatory variable

*logit [IV] [INSERT PREDICTOR] + [Control] + [Control]
*Highlight Between Comments

putexcel set "YourOutput.xls", replace

*Set Original Macros for the loop
local imputations 	= 					
local iteration 	= 
local pasteMat 		= 
local firstRow 		= 
local lastRow 		= 	
local varName 		= 

forvalues dataSet = 1(1)`imputations'{
use ".dta", clear
mi extract `dataSet'

putexcel A1=("Model") B1=("Variable") C1=("Coef") D1=("SE") A`firstRow':A`lastRow'=(`iteration') B`varName'=("IV") B`++varName'=("ControlOne") B`++varName'=("ControlTwo") B`++varName'=("Constant") 

*The actual regression we need to loop
quietly logit _IV _DV _ControlOne _ControlTwo

mat coef_temp = r(table)
mat coef= coef_temp[1..2,1...]'
mat list coef
putexcel C`pasteMat'=matrix(coef)

*Index the local macros as needed
local ++iteration
local pasteMat 	= 	`pasteMat'	+	[]
local firstRow 	= 	`firstRow'	+	[]
local lastRow 	= 	`lastRow'	+	[]
local ++varName
 }


*******************************************************************************
*********************Mediation analyses with imputed data**********************
*******************************************************************************

/*Goal:
1. Create a loop to run your estimatation through all imputed datasets seperately
2. Store estimates from each model in a matrix
3. Export coefficients and standard errors to Stata or Excel
4. Combine estimates to create estimates based on multiple imputation
*/

ssc install khb
cls

use "ImputationExampleData_110119_MICE.dta", clear
mi set wide

mi estimate: khb logit gang lowSES || bullied impulsecontrol, c(male) 

*The previous model will not run without the cmdok (command okay) option
mi estimate, cmdok: khb logit gang lowSES || bullied impulsecontrol, c(male) 

*But even when it runs, KHB will not display disentangle estimates for each mediator
mi estimate, cmdok: khb logit gang lowSES || bullied impulsecontrol, c(male) disentangle

*Q11 : So what can we do instead?


*******************************************************************************
*********************Put Excel for Disentangle Components**********************
*******************************************************************************

putexcel set "ExtractedKHB.xls", replace

local i = 3				
local n = 2					
local d = 1					
local l = 2					
local m = 3				
					
forvalues j = 1(1)`i'{
use "ImputationExampleData_110119_MICE.dta", clear
mi extract `j'

putexcel  A1=("Model") A`l':A`m'= (`d') B1=("Mediators") B`n'=("Bullied") B`m'=("ImpulseControl") C1=("Coef") D1=("SE") E1=("Pdiff") F1=("Pred")

khb logit gang lowSES || bullied impulsecontrol, c(male) disentangle

mat disentangle = e(disentangle)
*preseve the first two columns in their entirety
mat disentangleestimates = disentangle[1...,1..4]

putexcel C`n'=matrix(disentangleestimates)

local n = `n'+2
local d = `d'+1
local l = `l' + 2
local m = `m' + 2
}


********************************************************************************
****************************Margins with Imputed Data***************************
********************************************************************************

logit bullied usborn i.age lowSES pmon
mimrgns age, atmeans cmdmargins
marginsplot

*But Beware: Confidence intervals are not correct in marginsplot

********************************************************************************
********************Future Directions for cleaner workflow**********************
********************************************************************************


/****Matrix to data code 	https://stackoverflow.com/questions/32489985/stata-convert-a-matrix-to-dataset-without-losing-names

khb regress gang lowSES || bullied impulsecontrol headinjury pmon, c(male ib16.age location offendfreq) disentangle summary
matrix A = e(disentangle)

local rownames : rowfullnames A
local c : word count `rownames'

local names : colfullnames A
local newnames : subinstr local names "_cons" "cons", word

gen rownames = ""
forvalues i = 1/`c' {
    replace rownames = "`:word `i' of `rownames''" in `i'
}

svmat A,names(col)
mat list A

*/



