/***********************************************

coding and data committee workshop
----> 	user written commands
-->		ryan bowman

***********************************************/

//	use data
	global root "C:\Users\rybow\OneDrive - The Pennsylvania State University\Coding & Data Committee - SOC & CRIM - C&D Committee\Open Access Documents\2026 workshops\Feb 2026 - User written commands"
	* replace this string with your root folder containing the classdata .dta file
	
//	load data
	use "$root/classdata" , clear

**#*****************************************************
* asdoc
********************************************************
/*
asdoc is a useful command to make descriptive statistic tables, and tables for other commands like t-tests, chi-square, and other stata commands 

this command easily converts the table into a word file, but requires some editting once it is in word

by default, the command gives you N, mean, SD, min, and max -- but this can be customized 
*/

//	install and open help window 
	ssc install asdoc 
	help asdoc
	
//	overall summary statistics - variable labels 
	asdoc sum age i.race female realinc i.education, /// 
	save($root/asdoctable1.doc) /// save the table
	title(Table 1: Descriptive Statistics for Sample) /// title
	font(Times New Roman) fs(11) /// change font and text size
	dec(2) /// how many decimals 
	label /// use the variable label instead of the variable name 
	replace
	
//	overall summary statistics - variable name 
	asdoc sum age i.race female realinc i.education, /// 
	save($root/asdoctable2.doc) /// 
	title(Table 1: Descriptive Statistics for Sample) /// 
	font(Times New Roman) fs(11) /// 
	dec(2) /// 
	replace
	
**#*****************************************************
* desctable
********************************************************
/*
desctable is another option for descriptive statistics

this command outputs the table into an excel file, which can then be easily copy/pasted into a word document 

this command treats continuous and categorical variables differently, so requires a little less work after the table has been created 
*/

//	install the package 
	net install desctable, from("https://tdmize.github.io/data/desctable")
	help desctable

//	overall descriptive statistics 
	desctable age i.race i.female realinc i.education, ///
	stat(n mean sd min max) ///
	filename("$root/desctable1") ///
	decimals(2) notes("Note: You can put notes here.") fontsize(12)
	
//	descriptive statistics by groups
	desctable age i.race i.female realinc i.education, ///
	stat(n mean sd min max) ///
	filename("$root/desctable2") ///
	decimals(2) notes("Note: You can put notes here.") fontsize(12) ///
	group(race)
	
**#*****************************************************
*	catplot - making categorical bar charts 
********************************************************

//	install package 
	ssc install catplot , replace
		
	catplot  , 	///
		over(education) by(race) ///
		percent(race) ///	
		recast(hbar) ///
		blabel(bar, format(%4.1f) pos(outside))	
		
	catplot  , 	///
		over(marital, label(angle(20))) by(race, note("")) ///
		percent(race) ///	
		recast(bar) ///
		blabel(bar, format(%4.1f) pos(outside))	

**#*****************************************************
*	regression tables
**	esttab/eststo/estout
********************************************************
/*
esttab and its associated subcommands are great for storing regression estimates and outputting them into a table 
*/

//	install the package
	ssc install estout
	
//	save a few regressions
	eststo model1: ///
	reg realinc age
	
	eststo model2: ///
	reg realinc age i.race
	
	eststo model3: ///
	reg realinc age i.race i.female
	
	eststo model4: ///
	reg realinc age i.race i.female i.education
	
	esttab model* using "$root/esttab.rtf" , ///
		se mtitles b(2) se(2) r2 label ///
		title(Table 1: Sample Regressions) ///
		replace 
	
	
// outreg2 -- for Word -- easiest to use, less flexibility
	ssc install outreg2, replace
	help outreg2
	
	reg realinc age i.race i.female i.education
	outreg2 using "$root/outreg.doc", replace
	* a little clunkier, not as clean as esttab command
	
**#*****************************************************
* mplotoffset
********************************************************
/*
while you can do a lot of editting to marginsplots, some options just do not work

mplotoffset helps offsetting estimates that otherwise cannot be offset from the default marginsplot command
*/

//	install the package 
	ssc install mplotoffset
	help mplotoffset

//	estimate a regression 
	reg realinc age i.race i.female i.education
	
//	calculate the margins 
	margins, at(female=(0(1)1)) over(race)
	
//	default marginsplot
	marginsplot , recast(scatter)
	* notice how some of the estimates overlap each other? with some estimates, this can be very visually unappealing 
	
//	estimate with mplotoffset
	mplotoffset, ///
		recast(scatter) ///
		offset(.02) /// change how offset each estimate is
		legend(pos(6) col(3))

* another example *
//	estimate a regression 
	reg realinc age i.race##i.marital i.female i.education 
	
//	calculate the margins 
	margins, at(race=(1(1)3)) over(marital)
	
//	default marginsplot
	marginsplot , recast(scatter)
	* very hard to see the differences for many groups...
	
//	estimate with mplotoffset
	mplotoffset, ///
		recast(scatter) ///
		offset(.03) /// change how offset each estimate is
		legend(pos(6) col(5)) ///
		title(Predicted Income by Respondent's Race x Martial Status) ///
		ytitle(Predicted Income $)

**#*****************************************************
* marginscontplot2 
********************************************************
/*
this helpful command is great for visualizing continuous interactions in a marginsplot and makes the default look a little cleaner

you can also modify the at() options easier than in the default margins commands

this command also estimates the margins and makes the marginsplot in one command!
*/

//	install the package 
	ssc install marginscontplot2
	help marginscontplot2
	
//	estimate a regression 
	reg realinc c.age##c.age##i.race i.female i.education
	
//	calculate the margins 
	margins, at(age=(18(5)80)) over(race)
	
//	default marginsplot
	marginsplot 
	
//	estimate with marginscontplot2
	mcp2 age race, ///
		at1(% 10 (1) 90)  ///
		plotopts(title(Predicted Income by Age) ///
			ytitle(Predicted Income) legend(pos(6) col(3)))
	
//	add confidence intervals
	mcp2 age race, ///
		at1(% 10 (1) 90) ci plotopts(ycommon) sh
	* adding confidence intervals splits up the graphs 
	
//	estimate with different x scale
	mcp2 age race, ///
		at1(21 (5) 65)  ///
		plotopts(title(Predicted Income by Age) ///
			ytitle(Predicted Income) legend(pos(6) col(3)))

//	estimate a different regression 
	reg realinc c.age##c.age##i.female i.race i.education	

//	change labels for legend
	mcp2 age female, at1(% 10 (1) 90)  ///
	plotopts(title(Predicted Income by Age) ///
		ytitle(Predicted Income) legend(pos(6) col(2) ///
		label(1 "Male") label(2 "Female"))) 
	
//	estimate a different regression 
	reg realinc c.age##c.age##i.education i.female i.race 

//	mcp2 plot with different interaction
	mcp2 age education, ///
		at1(% 10 (1) 90)  ///
		plotopts ///
			(title(Predicted Income by Age) ///
			ytitle(Predicted Income) legend(pos(6) col(5) ///
			label(1 "No HS") label(2 "HS") label(3 "Some college") ///
			label(4 "College") label(5 "Post college")))
	
**#*****************************************************
* schemes 
********************************************************

//	install some schems 
	ssc install cleanplots , replace
	ssc install blindschemes , replace
	ssc install yalescheme , replace
	
//	estimate a regression 
	reg realinc age i.race i.female i.education i.marital
	
//	calculate the margins 
	margins, at(race=(1(1)3)) over(marital)
	
//	visualize with different schemes 
	mplotoffset, ///
		recast(scatter) ///
		offset(.05) /// 
		legend(pos(6) col(5)) ///
		scheme(cleanplots)
	
	mplotoffset, ///
		recast(scatter) ///
		offset(.05) /// 
		legend(pos(6) col(5)) ///
		scheme(plotplainblind)
	
	mplotoffset, ///
		recast(scatter) ///
		offset(.05) /// 
		legend(pos(6) col(5)) ///
		scheme(plotplain)
	
	mplotoffset, ///
		recast(scatter) ///
		offset(.05) /// 
		legend(pos(6) col(5)) ///
		scheme(plottig)
	
	mplotoffset, ///
		recast(scatter) ///
		offset(.05) /// 
		legend(pos(6) col(5)) ///
		scheme(yale)

**#*****************************************************
* other commands  
********************************************************

//	commands for mapping in stata
	ssc install spmap
	ssc install shp2dta
	ssc install geo2xy
	
//	other modeling techniques 
	ssc install gologit2
	ssc install psmatch2
	ssc install ebalance 