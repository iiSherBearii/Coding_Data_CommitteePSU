# Exercise 1
answer <- example %>% mutate(mpg_median = median(mpg))

# Exercise 2
answer2 <- mtcars %>% select(mpg, ends_with("t"))

# Exercise 3, AMC Javelin
answer3 <- mtcars %>% filter(gear == 3, carb == 2) %>% arrange(mpg)

# Exercise 4
answer4 <-
    mtcars %>%
    group_by(cyl) %>%
    mutate(rank = min_rank(mpg)) %>%
    filter(rank == max(rank)) %>%
    ungroup()

# Exercise 5
answer5 <-
    billboard %>%
    pivot_longer(cols = starts_with("wk"),
                 names_to = "week",
                 values_to = "place") %>%
    group_by(artist, track, date.entered) %>%
    filter(place == min(place, na.rm = T)) %>%
    ungroup()
