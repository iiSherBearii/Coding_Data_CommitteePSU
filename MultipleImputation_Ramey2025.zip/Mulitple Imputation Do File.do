* Clear the environment
clear all
set more off

*Here are a couple user written packages that I have found helpful
ssc install how_many_imputations /*As it says, this is von Hippel's package that he discusses in his article that you can run after your analytic model to assess how many extra imputations that you may need*/


findit misschk /*This is part of an older package of commands, but it allows you to examine patterns of missingness without having to mi set your data*/
 
ssc install mimrgns /*This allows you to run some marginal effects commands on imputed data*/

cd  "/Users/dmr45/Library/CloudStorage/OneDrive-ThePennsylvaniaStateUniversity/Spring 2025/Missing Data Lecture/Multiple Imputation in Stata - Ramey/"


/*******************************************
We are interested in how suspension, lack of readiness, and self-control predict delinquency. 
We hypothesize that the relationship between self-control and delinquency varies across boys and girls.
Our controls include income and father's incarceration. 
*******************************************/

use "MI Workshop - Raw FFCWBS Data.dta", clear


/*******************************************
Examine data before imputation
*******************************************/

d

summarize

*Remove respondents who are not in current wave 
keep if ck6kint ==1

gen f_selfcontrol1 = female*selfcontrol /*Interaction*/

gen ln_inc1  = ln(income+1) /*Log transformation*/



summarize

*Examine distribution of delinquency, readiness, and self-control
hist del, width(1) normal title("Delinquency Scores") 
hist selfcontrol, width(1) normal title("Self-Control") 
hist readiness, width(1) normal title("Self-Efficacy") 
hist income,   normal title("Income") 


*Identify observations with missing values on each variable - this is useful for figuring out "how much" missingness you actually have and can come in handy if you need to exclude observations with missing values after imputation
foreach var of varlist delinquency-schooltype {
	gen miss_`var' = missing(`var')
}



*First, run your complete case analysis
poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female /*Run the regression across all imputations and combine the results*/
*how_many_imputations
estimates store Model0

/*******************************************
Imputation Option #1: Impute, then Transform
*******************************************/


* Set up the multiple imputation framework
mi set  wide  /*Define the multiple imputation format (here, I use  wide format because it is often the easiest to begin with, other options include mlong,flong, or flongsep - Note that you can use the "mi convert" command to change between formats)*/
*mi convert mlong, clear
mi register imputed   delinquency suspended readiness selfcontrol income  dadjail  schooltype  assistance unemp  /*Register variables to be imputed & used in analyses*/

mi register passive f_selfcontrol1 ln_inc1   /*Register passive variables that will not be imputed but will be used in analysis*/

mi register regular idnum ck6kint female miss_* /*Not imputed, but used in the analyses*/

* Examine patterns of missingness in data
*I also recommend installing the misschk command, which allows you to examine missingness patterns without registering variables

mi describe
mi misstable summarize
mi misstable patterns
mi misstable sum
mi misstable sum, all
mi misstable nested


*Run our imputation model - I am using mi impute chained to account for (1) imputation of multiple variables at once and (2) the complex structure of the missing data suggests that we should use a more flexible approach
mi impute chained (poisson) delinquency (truncreg,ll(0)) income (reg)  readiness selfcontrol (logit)  assistance unemp suspended dadjail (mlogit) schooltype  = female  ,add(20) augment dots noisily 
 *Check the imputation results
mi describe  /*Display information about the imputed data*/
mi varying  
* Analyze the imputed data (description analysis)
mi xeq 0 1 10 20: sum delinquency  income readiness selfcontrol

mi xeq 0 1 10 20: tab1   suspended dadjail schooltype


mi estimate, post: mean delinquency  income readiness selfcontrol

mi estimate, post: proportion   suspended dadjail schooltype



*Create new variables to account for possible non-linearity (transform variables after imputation)

*Test 
mi passive: gen f_selfcontrol2  = female*selfcontrol /*Log transformation*/


mi passive: gen ln_inc2  = ln(income+1) /*Log transformation*/

mi xeq: sum ln_inc* f_selfcontrol*




* Analyze the imputed data (logistic regression analysis)
mi xeq 0 1 10 20:  poisson  delinquency suspended readiness selfcontrol  i.dadjail  income i.female


mi estimate, post: poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc2 f_selfcontrol2  i.female /*Run the regression across all imputations and combine the results*/
*how_many_imputations
estimates store Model1

*MID (We imputed the missing Ys, but now we can delete them according to von Hippel 2007)
mi estimate, post: poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc2 f_selfcontrol2 i.female if miss_delinquency ==0 /*Run the regression across all imputations and combine the results*/
estimates store Model2



*Test for joint significance of both readiness and selfcontrol
mi test readiness selfcontrol

*Test for equality of coefficients between readiness and selfcontrol (linear)
mi estimate (diff: _b[selfcontrol]-_b[readiness]), saving(miest, replace): poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc2 f_selfcontrol2 i.female 
mi testtransform diff


*Test for equality of coefficients between readiness and selfcontrol (non-linear)
mi estimate (diff1: _b[selfcontrol]-_b[readiness])( diff2: _b[ln_inc]-_b[readiness]), saving(miest, replace): poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc2 f_selfcontrol2 i.female 
mi testtransform diff1 diff2

/*******************************************
Imputation Option #2: Transform, then impute
*******************************************/

*Extract the original dataset 
mi extract 0, clear


* Set up the multiple imputation framework
mi set  wide  /*Define the multiple imputation format (here, I use  wide format because it is often the easiest to begin with, other options include mlong,flong, or flongsep - Note that you can use the "mi convert" command to change between formats)*/
*mi convert mlong, clear
mi register imputed   delinquency suspended readiness selfcontrol  dadjail  schooltype  assistance unemp f_selfcontrol1 ln_inc1  /*Register variables to be imputed & used in analyses*/

mi register passive  income  /*Register passive variables that will not be imputed but will be used in analysis*/

mi register regular idnum ck6kint female miss_* /*Not imputed, but used in the analyses*/

* Examine patterns of missingness in data
*I also recommend installing the misschk command, which allows you to examine missingness patterns without registering variables

mi describe
mi misstable summarize
mi misstable patterns
mi misstable sum
mi misstable sum, all
mi misstable nested


*Run our imputation model - I am using mi impute chained to account for (1) imputation of multiple variables at once and (2) the complex structure of the missing data suggests that we should use a more flexible approach
mi impute chained (poisson) delinquency (reg) ln_inc1   readiness selfcontrol f_selfcontrol1 (logit)  assistance unemp suspended dadjail (mlogit) schooltype  = female  ,add(20) augment dots noisily 
 *Check the imputation results
mi describe  /*Display information about the imputed data*/
mi varying  
* Analyze the imputed data (description analysis)

*Transform imputed values of ln_inc1 back into income variables for your descriptive statistics 
mi xeq: gen income2 = exp(ln_inc1)

 
*Check the imputation results
mi describe  /*Display information about the imputed data*/
mi varying  
* Analyze the imputed data (description analysis)
mi xeq 0 1 10 20: sum delinquency  income2 readiness selfcontrol

mi xeq 0 1 10 20: tab1   suspended dadjail schooltype


mi estimate, post: mean delinquency  income readiness selfcontrol

mi estimate, post: proportion   suspended dadjail schooltype


* Analyze the imputed data (logistic regression analysis)
mi xeq 0 1 10 20:  poisson  delinquency suspended readiness selfcontrol  i.dadjail  income i.female


mi xeq: sum ln_inc* f_selfcontrol*




mi estimate, post: poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female /*Run the regression across all imputations and combine the results*/
*how_many_imputations
estimates store Model3

*MID (We imputed the missing Ys, but now we can delete them according to von Hippel 2007)
mi estimate, post: poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female if miss_delinquency ==0 /*Run the regression across all imputations and combine the results*/
estimates store Model4


*Test for joint significance of both readiness and selfcontrol
mi test readiness selfcontrol

*Test for equality of coefficients between readiness and selfcontrol (linear)
mi estimate (diff: _b[selfcontrol]-_b[readiness]), saving(miest, replace): poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female 
mi testtransform diff


*Test for equality of coefficients between readiness and selfcontrol (non-linear)
mi estimate (diff1: _b[selfcontrol]-_b[readiness])( diff2: _b[ln_inc]-_b[readiness]), saving(miest, replace): poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female 
mi testtransform diff1 diff2


esttab Model0 Model1 Model2 Model3 Model4, se star label ///
  title("Poisson Models Comparison") ///
  mtitles("Complete Case Using Listwise Deleltion" "MI Model - Impute, then Transform" "MID Model" "MID Model - Impute, then Transform" "MI Model - Transform, then Impute" "MID Model" "MID Model - Transform, then Impute" ) ///
  scalars("N")

  

  
mi estimate, post: poisson  delinquency suspended readiness selfcontrol  i.dadjail  ln_inc1 f_selfcontrol1 i.female /*Run the regression across all imputations and combine the results*/
how_many_imputations


 
mi impute chained (poisson) delinquency (reg) ln_inc1   readiness selfcontrol f_selfcontrol1 (logit)  assistance unemp suspended dadjail (mlogit) schooltype  = female  ,add(55) augment dots noisily 

save "MI Workshop - Final Imputed FFCWBS Data.dta", replace

