//Bring in the data
use "C:\Users\alexc\Downloads\FirstYearClass\Publication_example.dta", clear //check filepath

*Project Idea*
*What journals are publishing on networks and health, and what is their impact?
*Downloaded Web of Science data including article published on the topic and the number of times they have been cited.

codebook *

***Inlist Example***
//Make variable to account for journal categories
gen outlet = 0 //all journals
replace outlet=1 if journal=="JOURNAL OF HEALTH AND SOCIAL BEHAVIOR"
replace outlet=2 if inlist(journal, "SOCIAL FORCES", "AMERICAN JOURNAL OF SOCIOLOGY", "AMERICAN SOCIOLOGICAL REVIEW") //if the inlist statement is true replace outlet=2

****Publication Count*****
*The following loop counts the number of publications within the year for each 
*journal category (other, jhsb, and top3). The if statement ensures that only 
*outlets of that type are counted. The local i is a way for stata to count, 
*where it is essentially counting through the loop for each variable. i = 0 
*when the loop goes through other journals, i = 1 when the loop goes through 
*jhsb publications, and i = 2 when the loop goes through the top 3 soc journals 
*(SF, ASR, AJS). This egen command simply counts the number of nonmissing 
*observations within that journal year.

local i = 0 // to equal 0 since when outlet = 0 it refers to other publications
foreach x in other jhsb top3 { //do the following for each of these three words (plug in x where I say)
	bysort outlet year: egen `x'=count(year) if outlet==`i' //Note egen and bysort
	local i = `i'+1 // for the next time we loop through i will be one higher
}
//total publications inclusive of all categories
bysort year: egen total=count(year) //we dont need the outlet sort, we just want the total observations in that year

****Citations***
*The only difference between this loop and the last is the egen command here. 
*In this case we sum the number of citations since each publication contributes 
*its own number of citations.
local i = 0 
foreach x in othercite jhsbcite top3cite {
	bysort outlet year: egen `x'=sum(totalcitations) if outlet==`i' //note sum*
	local i = `i'+1
}

//total citations inclusive of all categories
bysort year: egen totalcite=sum(totalcitations) //again, total citations in that year

//collapse observations to year
collapse (mean) othercite jhsbcite top3cite totalcite (count) other jhsb top3 total, by(year)

//replace "." with 0 because they should be 0 citations not missing values
foreach x of varlist othercite jhsbcite top3cite totalcite {
    label variable `x' "Mean number of citations for articles published that year"
	replace `x' = 0 if `x'==.
}

//replace "." with 0 because they should be zero publications not missing values
foreach x of varlist other jhsb top3 total { //for each variable in the list
    label variable `x' "Count of Publications at Journal that year"
	replace `x' = 0 if `x'==.
}

***Inrange Example***
list year other* jhsb* top3* if inrange(year, 2000, 2010)
