//Bring in the data
use "C:\Users\alexc\Downloads\FirstYearClass\Publication_example2.dta", clear //check filepath

*Project Idea*
*What journals are publishing on networks and health, and what is their impact?
*Downloaded Web of Science data including article published on the topic and 
*the number of times they have been cited.

*Part of paper argument is trends pre and post 2000 (maybe which journals 
*matter changes across time, particularly pre-post 2000 due to HIV research 
*and Add Health among other developments)

codebook *

***Inlist Example***
//Make variable to account for journal categories
gen outlet = 0 //all journals
replace outlet=1 if journal=="JOURNAL OF HEALTH AND SOCIAL BEHAVIOR"
replace outlet=2 if inlist(journal, "SOCIAL FORCES", "AMERICAN JOURNAL OF SOCIOLOGY", "AMERICAN SOCIOLOGICAL REVIEW") //if the inlist statement is true replace outlet=2

gen outlet2=outlet+0.5 // to help graph easily

//Egen Example without by, using wide data

//citations pre 2000
egen cite2000=rowtotal(yr1976-yr1999) //rowtotal adds each variable in the list
*you specify so here it adds all values from yr1976 through yr1999

//citations post 2000
egen cite2020=rowtotal(yr2000-yr2020) //

//visualize findings
twoway (scatter cite2000 outlet, jitter(5)) (scatter cite2020 outlet2, jitter(5))
