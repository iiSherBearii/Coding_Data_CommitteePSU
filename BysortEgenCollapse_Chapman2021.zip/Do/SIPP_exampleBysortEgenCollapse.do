******************************************************************************
*I have kept a small number of observations from the 2014 SIPP Panel for a 
*couple of examples. These data are organized long such that there are multiple 
*observations (rows) for each household and household occupants. This follows 
*households for up to 48 months from January 2013-December 2016.

//Bring in the data
use "C:\Users\alexc\Downloads\FirstYearClass\SIPP_example.dta", clear //make sure the filepath is correct for you

codebook * // four variables: hhid, month, citizenship, race_r

//Browse the data to get an idea of what we are working with. 
*Remember, I only kept a small number of observations, there were around 2.5
*million observations in the raw file

***BYSORT EXAMPLE***
*I want a variable that counts the number of people within each household for each month*
bysort hhid month: gen hhsize=_N //this sorts the data by (bysort) household ID 
*(hhid) and month and generates a variable (hhsize) that equals the total 
*number of observations (residents (_N)) within that household month.

*Now I think I might also like a constant for the average number of
*residents in a household during their time in the study. 
bysort hhid: gen meanhhsize=mean(hhsize) // Why doesnt this work?!? Well generate doesn't let you use functions like "mean".

*However, there is HOPE! egen (extended generation) offers lots of cool 
*functions to generate new variables
help egen

***BYSORT EXAMPLE WITH EGEN***
bysort hhid: egen meanhhsize=mean(hhsize) //this sorts the data by (bysort) 
*household ID (hhid) and generates a variable (meanhhsize) that equals the sum 
*of hhsize for all observations for the household ID divided by the number of 
*observations.

*Okay now I think it would be nice to have a variable that shows the deviation 
*from the mean household size
gen devhhsize=hhsize - meanhhsize //substracts the mean household size from the 
*household size for very observation and generates a variable (devhhsize) to 
*indicate the difference

*For my theoretical model, maybe the propotion of the household that is 
*foreignborn is important (maybe more convincing as the proportion of a school 
*or neighborhood; this code applies to those situations as well). Maybe also a flag for whether a foreignborn person lives in a household.

***EXAMPLE WITH EGEN***
bysort hhid: egen meanborn=mean(citizenship) //over the entire period
bysort hhid month: egen meanborn_m=mean(citizenship) //within each month

bysort hhid month: egen fbflag=max(citizenship) // = 1 if any household ID 
*months have a foreignborn person because maximum value of citizenship is 1 if 
*a person is foreignborn

***EXAMPLE WITH COLLAPSE***
collapse (mean) meancitizenship=citizenship (count) hsize=meanborn (max) foreignbornflag=citizenship, by(hhid month) 
*this collapses the data to one observation per household ID month (by hhid month)
*where it records the mean of citizenship (proportion foreignborn; 
*newvarname=oldvar [meancitizenship=citizenship]), the count of observations of 
*meanborn (any nonmissing variable here will give the same value), and the 
*maximum value of citizenship (a flag for whether or not a foreignborn person 
*lives in the household in that month.

*Okay merge these into the original dataset
merge 1:m hhid month using "C:\Users\alexc\Downloads\SIPP_example.dta", nogenerate

browse //note that the variables we made with collapse are the same values as 
*those we made with egen (except the deviation variable).

save "C:\Users\alexc\Downloads\collapse_example.dta", replace