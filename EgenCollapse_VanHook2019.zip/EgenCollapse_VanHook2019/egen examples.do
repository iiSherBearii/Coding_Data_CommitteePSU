use "/Users/jennifervanhook/Documents/Teaching/acs2017.dta", clear
/* Total Household Size */
egen hhsize = count(pernum), by(serial)
list serial pernum age sex relate hhsize in 1/10

/* number of children ages 0-17 in HH */
gen child = (age>=0 & age<=17)
tab child
egen hhchildren = total(child), by(serial)
list serial pernum age sex relate child hhchildren in 1/10

/* average age of all persons in the HH */
egen aveage = mean(age), by(serial)
list serial pernum age aveage in 1/10

/* age of youngest person in household */
egen minage = min(age), by(serial)
list serial pernum age aveage minage in 1/10

/* person-number of youngest person in HH */
egen rankage = rank(age), by(serial) track 
gen youngid = 0
replace youngid = pernum if rankage==1
egen youngestid = max(youngid), by(serial)

/* finding Siblings and Twins */
sort serial momloc age 
replace momloc = . if momloc == 0
egen nsibs = count(momloc), by(serial momloc)
tab nsibs

egen ntwins = count(momloc), by(serial momloc age)
tab ntwins

/* create an ID number:  sibling ID number */
bysort serial momloc: gen sibidnum = _n
replace sibidnum = . if nsibs==0


/* COLLAPSE Example:  state characteristics */
save temp, replace  /* save your original data set in case you want to go back to it */
use temp, clear
gen pop = 1
gen imm = (citizen == 2 | citizen==3)

gen white = (race==1 & hispan == 0)
gen black = (race ==2 & hispan == 0)
gen asian = ((race==4 | race==5 | race==6) & hispan==0)
gen latino = (hispan>=1)
gen other = (white==0 & black==0 & asian==0 & latino == 0)

collapse (sum) pop imm white asian latino other ///
       (mean) prop_imm=imm prop_white=white  prop_asian=asian  ///
	         prop_latino=latino prop_other=other [pw=perwt], ///
	    by(statefip)




	 


