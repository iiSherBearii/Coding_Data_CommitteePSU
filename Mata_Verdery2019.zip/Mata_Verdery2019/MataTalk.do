////////////////////////////////////////////////////////////////////////////////
///Do file for "Introduction to Mata" talk at PRI. Created 10/17/2019. By Ashton
//Note, this won't run as a script and must be interactively done because I 
//intentionally put things in there that will fail (multiplications that don't 
//work, etc.)
////////////////////////////////////////////////////////////////////////////////
clear all

/////////
//Slide 3
//show stata command to initialize empty data sheet
set obs 10
//show mata command to initialize identity matrix; alternate: mata: I(10)
mata
	I(10)
end

/////////
//Slide 5
//show assignment and evaluation don't work in regular stata
x=5
5+2
//show they work in mata
mata
	x=5
	5+2
	x+2
	x
	x,x
	(x,x)\(x*x,x+x)
	//inset to slide to show elementwise vs. regular matrix operations
	c=(x,x)\(x*x,x+x)
	v=(x,x+2)
	c*v
	c+v
	c:+v
	c*c
	c*v'
	//side note for jenny (not in slide), how to square every element
	mata (x,x)
	mata (x,x):^2
end	

/////////
//Slide 7
//build a mata function called add (not shown in slides) and show how it 
//looks in the mata environment
capture mata mata drop add()
mata
	function add(input1,input2)
	{
	return(input1+input2)
	}
end
//show how mata's environment commands work
mata mata des
mata
	mata des
end
//show how removing stuff works
mata mata drop add()
mata mata des
//show that clear doesn't clear mata
clear
mata mata des
//show that clear all clears mata
clear all
mata mata des

/////////
//Slide 8
//create some random data and show how to put it into and get it out of mata
set obs 10
gen x=_n
//putting one variable into a vector
putmata x
lis x
mata x
//putting multiple vaiables into a matrix
gen y1=uniform()
gen y2=uniform()
putmata y=(y1 y2)
lis y1 y2
mata y
//getting variables out of mata
getmata matax=x
getmata (y1mata y2mata)=y
//show interaction assignment of strings
mata: Ashton="Hilarious"
mata: Ashton
//show how to bring in a matrix from within mata
mat x=J(2,4,uniform())
mata: st_matrix("x")
mata: y=st_matrix("x"):+1
mata: st_matrix("x2",y)
mat lis x2
//show a local
local PRI=100
mata: st_local("PRI")

/////////
//Slide 9
mata
	//show row joins
	x=1,2,3,4,5
	x
	//show column joins
	y=1\2\3\4\5
	y
	//show more complex joins
	y,y
	x,x
	x\(y,y,y,y,y)
	//show string joins
	//need strings to be strings
	Ashton,Verdery
	"Ashton","Verdery"
	"Ashton"\"Verdery"
	//cant directly combine numbers and strings
	"Ashton"\"Verdery"\2.0
	//can do so after transform (but watch out for those decimals)
	"Ashton"\"Verdery"\strofreal(2.0)
end

/////////
//Slide 10
//show some shorthand notation; first columnwise
mata
	1::5
	//next rowwise
	1..5
	//show it works with decimals
	1.1..5.1
	//and some of the issues therein
	1.2..5.2
	1.2..5.1
	//create a matrix to show matrix extraction shorthand
	x=1..5
	x=x\x\x
	x
	//show matrix extraction shorthand
	x[1,.]
	x[.,1]
	//show you don't need the dot
	x[1,]
end
	
/////////
//Slide 11
mata
	//create a matrix to show matrix extraction
	x=(1,2,3,4,5)\(6,7,8,9,10)\(11,12,13,14,15)
	x
	//extract the row=1,col=2 element
	x[1,2]
	//extract the elements in rows 1 & 2 of column 2
	x[1..2,2]
	//more complex extractions
	x[(1,3),(2,4)]
	x[(1,2),(2..4)]
	//show you can't extract with scalar notation from a matrix
	x[1]
	//show you can extract with scalar notation from a vector
	y=1,2,3
	y[2]
	//show permutation (note will differ to extent that seeds differ)
	x
	perm=ceil(runiform(3,1)*3)
	perm
	x[perm,.]
	//exact examples in slide
	perm=3\3\3
	x[perm,.]
	perm=3\2\1
	x[perm,.]
	//show more complex extractions
	y=x[.,2..4]
	y
	x[2,y[1,1..3]]
	z=-1::-10
	z
	z[x[2,y[1,1..3]]]


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//Example of mata analysis, based on hypothetical problem Sarah Font sent me.
//Set up of problem (from her email):
	//The basic issue is that XX wants to use the NCANDS data to identify 
	//sibling groups in the AFCARS (foster care) data at the individual level. 
	//The linkage between NCANDS and AFCARS is easy, but the identification of 
	//sibling groups is pretty indirect. So, the report ID should be common 
	//across siblings at a given point in time, but a child may have multiple 
	//reports which may include different combinations of siblings (because 
	//they may not all be alleged victims on every report). So, I suggested 
	//measuring a child's sibling group to include any child that was on the 
	//same report as that child in the year preceding their removal, rather 
	//than relying on a single report. That obviously makes things more 
	//complicated, so I wonder if you had an idea of how to do this (ideally 
	//in stata). Let me know if my description is not making sense!
	//
	//The data would be like below, with ChildID and RptID (I just filled in 
	//SibID manually for this example) and we would want a simplified way of 
	//creating SibID across maybe ~1 million observations, that connects across 
	//all reports/children
	//ChildID 	RptID 	SibID
	//1 	1 	1
	//1 	2 	1
	//2 	2 	1
	//3 	2 	1
	//4 	3 	2
	//4 	4 	2
	//5 	3 	2
	//6 	3 	2
	//7 	3 	2
	//7 	4 	2
	//7 	5 	2
	//7 	6 	2
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//create the data
clear all
mata: data=(1,1,1)\(1,2,1)\(2,2,1)\(3,2,1)\(4,3,2)\(4,4,2)\(5,3,2)\(6,3,2)\(7,3,2)\(7,4,2)\(7,5,2)\(7,6,2)
mata: data
getmata (childid rptid sibid)=data
lis
mata mata drop data

//give kids an ID that runs 1:N
egen childid_1toN=group(childid)

//get report IDs that run 1:N
egen rptid_1toN=group(rptid)

//put in mata to get sets
putmata dframe=(childid_1toN rptid_1toN), replace

///////////////////////////////////////
****************
*Utility code to create a matrix with ids and component numbers
capture mata: mata drop components()
mata:
function components(real matrix canreach)
{
//double check to make sure it is symetric
	canreach=canreach+canreach'

//double check to be sure rid of people on the diagonal
	for (i=1;i<=rows(canreach);i++) canreach[i,i]=0

//make sure the reachability matrix is binary
	canreach=!!canreach

//assign person numbers in the columns
	temp=J(1,rows(canreach),.)
	for (i=1;i<=rows(canreach);i++) temp[1,i]=i
	canreachtemp=canreach:*temp

//initialize the matrix of people who have been checked (in any component, starting with person 1)
	checked=J(1,1,1)

//initialize a matrix of people who have not been checked (in any component)
	notchecked=temp
	
//initialize the matrix of people to check (in that component, starting with person 1)
	tocheck=uniqrows((1,canreachtemp[1,.])')'

//initialize the person being checked (start with 1)
	beingchecked=1

//initialize the component storage structure
	//max size will be either everyone in their own component or everyone in one component
	compcensus=J(rows(canreach),rows(canreach),.)

//initialize the component index
	cindx=1

//go until everyone in the network has been checked
	while (cols(checked)<=cols(canreach)){
		//initialize a person in component index
			pindx=1	
		//take the first person who remains unchecked, if this is not the first component
			if (cindx>1) tocheck=((tocheck,notchecked[1,1])')'
	
		//go through the others in the component and add them to the component storage structure
			while (cols(tocheck)>1){
				//find the next person
					beingchecked=tocheck[1,2]
					checked=uniqrows((checked,beingchecked)')'
				//add them to the component storage structure
					if (beingchecked!=0) compcensus[cindx,pindx]=beingchecked
				//add their friends to the list to be checked (in this component)
					if (beingchecked!=0) tocheck=uniqrows((tocheck,canreachtemp[beingchecked,.])')'
				//remove those checked from those to be checked (in this component)
					removethese=J(1,cols(tocheck),0)
					for (i=1;i<=cols(checked);i++){
						removethese=removethese+strmatch(strofreal(tocheck),strofreal(checked[1,i]))
						}
					tocheck=uniqrows((tocheck:*!removethese)')'
				//show progress (turned off for now):
					//display("component")
					//cindx
					//display("person")
					//pindx
					//display("left to check")
					//tocheck
				//update the person index
					pindx=pindx+1
				}	
		//remove those checked from those not checked (in any component)
			removethese=J(1,cols(notchecked),0)
			for (i=1;i<=cols(checked);i++){
				removethese=removethese+strmatch(strofreal(notchecked),strofreal(checked[1,i]))
				}
			notchecked=uniqrows((notchecked:*!removethese)')'
			if (cols(notchecked)>1) notchecked=notchecked[1,2..cols(notchecked)]
		//update the component index
			cindx=cindx+1
		}
	//format the census results to long form (col 1 is person, col 2 is component number)
		components=J(nonmissing(compcensus),2,.)
		k=1
		for (i=1;i<=rows(compcensus);i++){
			for (j=1;j<=nonmissing(compcensus[i,.]);j++){
				if (compcensus[i,j]!=.){
					components[k,1]=compcensus[i,j]
					components[k,2]=i
					k=k+1
					}
				}
			}		
	//return out the components census in long form
		return(components)
}
end
///////////////////////////////////////

///////////////////////////////////////
//open mata and use a matrix multiplication approach
mata
	//fill in a matrix of IDs to Reports
	chi2rpt=J(max(dframe[.,1]),max(dframe[.,2]),0)
	for (k=1;k<=rows(dframe);k++){
		chi2rpt[dframe[k,1],dframe[k,2]]=1
		}
	//Get sibsets (weakly connected components in the multiplied matrix chi2rpt*chi2rpt')
	sibsets=components(chi2rpt*chi2rpt')	
end
///////////////////////////////////////

///////////////////////////////////////
//merge on the new sib IDs
preserve
	drop _all
	getmata (childid_1toN sibsetid)=sibsets
	sort childid_1toN
	tempfile tmp
	save `tmp', replace
restore
sort childid_1toN
merge m:1 childid_1toN using `tmp'
	//check if merge worked
	tab _merge
	drop _merge
	
//list results
lis
